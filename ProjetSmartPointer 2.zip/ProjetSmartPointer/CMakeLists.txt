cmake_minimum_required(VERSION 3.16)
project(Bibliotheque LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

file(GLOB_RECURSE SOURCES CONFIGURE_DEPENDS Private/*.cpp)
add_executable(build main.cpp ${SOURCES}
        Public/LibraryLogger.h
        Private/LibraryLogger.cpp
        Public/Interfaces/IBookState.h
        Public/States/AvailableState.h
        Private/States/AvailableState.cpp
        Public/States/CheckedOutState.h
        Private/States/CheckedOutState.cpp
        Private/States/ReservedState.cpp
        Public/States/ReservedState.h
        Public/States/DamagedState.h
        Private/States/DamagedState.cpp
        Public/Books/Book.h
        Private/Books/Book.cpp
        Public/Books/PhysicalBook.h
        Private/Books/PhysicalBook.cpp
        Private/Books/EBook.cpp
        Public/Books/EBook.h
        Private/Books/AudioBook.cpp
        Public/Books/AudioBook.h
        tests/test_books.cpp
        Public/Interfaces/IDisplayable.h
        Public/Interfaces/IFactory.h
        Public/Factories/FactoryRegistry.h
        Public/Factories/PhysicalBookFactory.h
        Private/Factories/PhysicalBookFactory.cpp
        tests/test_physical_factory.cpp
        Public/Factories/EBookFactory.h
        Private/Factories/EBookFactory.cpp
        tests/test_ebook_factory.cpp
        Public/Factories/AudioBookFactory.h
        Private/Factories/AudioBookFactory.cpp
        tests/test_audio_factory.cpp
        Public/Factories/BookFactoryRegistry.h
        Private/Factories/BookFactoryRegistry.cpp
        tests/test_book_registry.cpp
        Private/Members/Teacher.cpp
        Private/Members/Student.cpp
        Private/Members/Member.cpp
        Public/Members/Teacher.h
        Public/Members/Student.h
        Public/Members/Member.h
        Private/Factories/StudentFactory.cpp
        Public/Factories/StudentFactory.h
        Public/Factories/TeacherFactory.h
        Private/Factories/TeacherFactory.cpp
        Public/Interfaces/IBookObserver.h
        Public/Commands/Cart.h
        Private/Commands/cart.cpp
        Public/Interfaces/ICommand.h
        Private/Factories/MemberFactoryRegistry.cpp
        Public/Factories/MemberFactoryRegistry.h
        tests/test_member_registry.cpp
        tests/test_csv_integration.cpp
        Public/Interfaces/ISortStrategy.h
        Public/Strategies/SortByTitle.h
        Private/Strategies/SortByTitle.cpp)

# Seul Public est expose : les inclusions s'ecrivent avec leur
# sous-dossier, par exemple #include "Books/Book.h".
target_include_directories(build PRIVATE Public)

if (MSVC)
    target_compile_options(build PRIVATE /W4)
else ()
    target_compile_options(build PRIVATE -Wall -Wextra -Wpedantic)
endif ()

# Les fichiers CSV sont lus depuis le dossier d'execution.
configure_file(books.csv ${CMAKE_BINARY_DIR}/books.csv COPYONLY)
configure_file(members.csv ${CMAKE_BINARY_DIR}/members.csv COPYONLY)
configure_file(library_attendu.log ${CMAKE_BINARY_DIR}/library_attendu.log COPYONLY)
