
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include "Books/Book.h"
#include "Factories/PhysicalBookFactory.h"

int main()
{
    PhysicalBookFactory factory;

    std::vector<std::string> valid = {
        "physical", "Dune", "Frank Herbert", "SF-12", "bon"
    };

    std::vector<std::string> damaged = {
        "physical", "Les Miserables", "Victor Hugo",
        "CL-03", "endommage"
    };

    std::vector<std::string> invalid = {
        "physical", "Livre", "Auteur", "A-01", "inconnu"
    };

    auto book1 = factory.Create(valid);
    auto book2 = factory.Create(damaged);
    auto book3 = factory.Create(invalid);

    const bool test1 =
        book1 && book1->GetStateLabel() == "AvailableState";

    const bool test2 =
        book2 && book2->GetStateLabel() == "DamagedState";

    const bool test3 = (book3 == nullptr);

    std::cout << (test1 ? "[OK]" : "[ECHEC]")
              << " Livre en bon etat\n";

    std::cout << (test2 ? "[OK]" : "[ECHEC]")
              << " Livre endommage\n";

    std::cout << (test3 ? "[OK]" : "[ECHEC]")
              << " Ligne invalide refusee\n";

    return (test1 && test2 && test3) ? 0 : 1;
}
