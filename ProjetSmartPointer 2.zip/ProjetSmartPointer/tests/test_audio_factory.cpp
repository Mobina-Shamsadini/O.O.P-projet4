
#include <iostream>
#include <string>
#include <vector>

#include "Books/AudioBook.h"
#include "Books/Book.h"
#include "Factories/AudioBookFactory.h"

// Compteurs des tests.
int passed = 0;
int failed = 0;

// Affiche le resultat d'un test.
void Check(const std::string& description, bool condition)
{
    if (condition)
    {
        std::cout << "[OK] " << description << '\n';
        ++passed;
    }
    else
    {
        std::cout << "[ECHEC] " << description << '\n';
        ++failed;
    }
}

int main()
{
    AudioBookFactory factory;

    std::cout << "=== TESTS AUDIOBOOK FACTORY ===\n";

    // ==================== DONNEES VALIDES ====================

    const std::vector<std::string> valid = {
        "audio",
        "Le Petit Prince",
        "Antoine de Saint-Exupery",
        "Bernard Giraudeau",
        "96",
        "2"
    };

    auto book = factory.Create(valid);

    Check("Creation du livre audio",
          book != nullptr);

    Check("Titre correct",
          book && book->GetTitle() == "Le Petit Prince");

    Check("Type correct",
          book && book->GetTypeLabel() == "Audio");

    Check("Etat initial disponible",
          book && book->GetStateLabel() == "AvailableState");

    const auto* audio =
        dynamic_cast<const AudioBook*>(book.get());

    Check("Type dynamique AudioBook",
          audio != nullptr);

    Check("Narrateur correct",
          audio && audio->GetNarrator() == "Bernard Giraudeau");

    Check("Duree correcte",
          audio && audio->GetDurationMinutes() == 96);

    Check("Deux licences disponibles",
          audio && audio->GetMaxListeners() == 2);

    // ==================== DONNEES INVALIDES ====================

    Check("Duree nulle refusee",
          factory.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "0", "2"
          }) == nullptr);

    Check("Duree negative refusee",
          factory.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "-10", "2"
          }) == nullptr);

    Check("Duree non numerique refusee",
          factory.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "abc", "2"
          }) == nullptr);

    Check("Duree partiellement numerique refusee",
          factory.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "96abc", "2"
          }) == nullptr);

    Check("Zero licence refuse",
          factory.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "96", "0"
          }) == nullptr);

    Check("Nombre negatif de licences refuse",
          factory.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "96", "-2"
          }) == nullptr);

    Check("Nombre de licences non numerique refuse",
          factory.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "96", "abc"
          }) == nullptr);

    Check("Narrateur vide refuse",
          factory.Create({
              "audio", "Livre", "Auteur",
              "", "96", "2"
          }) == nullptr);

    Check("Mauvais type refuse",
          factory.Create({
              "ebook", "Livre", "Auteur",
              "Narrateur", "96", "2"
          }) == nullptr);

    Check("Champ manquant refuse",
          factory.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "96"
          }) == nullptr);

    // ==================== EMPRUNTS ====================

    if (audio != nullptr)
    {
        std::string output;

        Check("Premier emprunt accepte",
              book->Checkout(output));

        Check("Deuxieme emprunt accepte",
              book->Checkout(output));

        Check("Capacite maximale atteinte",
              audio->GetActiveListeners() == 2);

        Check("Troisieme emprunt refuse",
              !book->Checkout(output));

        Check("Retour accepte",
              book->Return(output));

        Check("Une licence liberee",
              audio->GetActiveListeners() == 1);
    }

    // ==================== DESTRUCTION ====================

    book.reset();

    Check("Aucun livre vivant apres destruction",
          Book::GetLiveCount() == 0);

    std::cout << "\nTests reussis : " << passed << '\n';
    std::cout << "Tests echoues : " << failed << '\n';

    return failed == 0 ? 0 : 1;
}
