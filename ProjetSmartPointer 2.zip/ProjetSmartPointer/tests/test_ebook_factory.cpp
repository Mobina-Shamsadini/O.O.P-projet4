
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include "Books/Book.h"
#include "Books/EBook.h"
#include "Factories/EBookFactory.h"

// Compteurs des tests.
int passed = 0;
int failed = 0;

// Verifie une condition et affiche son resultat.
void Check(const std::string& description, bool condition)
{
    if (condition)
    {
        std::cout << "[OK] " << description << '\n';
        ++passed;
    }
    else
    {
        std::cout << "[ECHEC] " << description << '\n';
        ++failed;
    }
}

int main()
{
    EBookFactory factory;

    std::cout << "=== TESTS EBOOK FACTORY ===\n";

    // ==================== DONNEES VALIDES ====================

    std::vector<std::string> valid = {
        "ebook",
        "Fondation",
        "Isaac Asimov",
        "https://biblio.uqac.ca/fondation",
        "4"
    };

    auto book = factory.Create(valid);

    Check("Creation du livre numerique",
          book != nullptr);

    Check("Titre correct",
          book && book->GetTitle() == "Fondation");

    Check("Type correct",
          book && book->GetTypeLabel() == "Numerique");

    Check("Etat initial disponible",
          book && book->GetStateLabel() == "AvailableState");

    // Verifie les attributs propres a EBook.
    const auto* ebook =
        dynamic_cast<const EBook*>(book.get());

    Check("Type dynamique EBook",
          ebook != nullptr);

    Check("Taille du fichier correcte",
          ebook && ebook->GetFileSizeMb() == 4);

    // ==================== DONNEES INVALIDES ====================

    std::vector<std::string> invalidSize = {
        "ebook", "Livre", "Auteur", "https://exemple.ca", "abc"
    };

    Check("Taille non numerique refusee",
          factory.Create(invalidSize) == nullptr);

    std::vector<std::string> zeroSize = {
        "ebook", "Livre", "Auteur", "https://exemple.ca", "0"
    };

    Check("Taille nulle refusee",
          factory.Create(zeroSize) == nullptr);

    std::vector<std::string> negativeSize = {
        "ebook", "Livre", "Auteur", "https://exemple.ca", "-5"
    };

    Check("Taille negative refusee",
          factory.Create(negativeSize) == nullptr);

    std::vector<std::string> partiallyNumeric = {
        "ebook", "Livre", "Auteur", "https://exemple.ca", "4abc"
    };

    Check("Taille partiellement numerique refusee",
          factory.Create(partiallyNumeric) == nullptr);

    std::vector<std::string> missingUrl = {
        "ebook", "Livre", "Auteur", "", "4"
    };

    Check("URL vide refusee",
          factory.Create(missingUrl) == nullptr);

    std::vector<std::string> wrongType = {
        "physical", "Livre", "Auteur",
        "https://exemple.ca", "4"
    };

    Check("Mauvais type refuse",
          factory.Create(wrongType) == nullptr);

    std::vector<std::string> missingField = {
        "ebook", "Livre", "Auteur", "4"
    };

    Check("Champ manquant refuse",
          factory.Create(missingField) == nullptr);

    // ==================== VERIFICATION FINALE ====================

    book.reset();

    Check("Aucun livre vivant apres destruction",
          Book::GetLiveCount() == 0);

    std::cout << "\nTests reussis : " << passed << '\n';
    std::cout << "Tests echoues : " << failed << '\n';

    return failed == 0 ? 0 : 1;
}
