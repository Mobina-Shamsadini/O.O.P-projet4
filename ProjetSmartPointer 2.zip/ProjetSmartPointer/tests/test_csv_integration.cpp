
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include "Books/Book.h"
#include "Books/PhysicalBook.h"
#include "Books/EBook.h"
#include "Books/AudioBook.h"

#include "Members/Member.h"
#include "Members/Student.h"
#include "Members/Teacher.h"

#include "Factories/BookFactoryRegistry.h"
#include "Factories/MemberFactoryRegistry.h"

#include "Loading/CsvLoader.h"

// ==================== COMPTEURS ====================

int passed = 0;
int failed = 0;

// Affiche le resultat de chaque verification.
void Check(const std::string& description, bool condition)
{
    if (condition)
    {
        std::cout << "[OK] " << description << '\n';
        ++passed;
    }
    else
    {
        std::cout << "[ECHEC] " << description << '\n';
        ++failed;
    }
}

// ==================== TEST PRINCIPAL ====================

int main()
{
    std::cout << "=== TEST INTEGRATION CSV ===\n";

    Check("Aucun livre initialement vivant",
          Book::GetLiveCount() == 0);

    Check("Aucun membre initialement vivant",
          Member::GetLiveCount() == 0);

    {
        // ==================== REGISTRES ====================

        const BookFactoryRegistry bookRegistry;
        const MemberFactoryRegistry memberRegistry;

        // ==================== CHARGEMENT ====================

        std::cout << "\n=== Chargement books.csv ===\n";

        auto books = CsvLoader::LoadCsv(
            "books.csv", bookRegistry
        );

        std::cout << "\n=== Chargement members.csv ===\n";

        auto members = CsvLoader::LoadCsv(
            "members.csv", memberRegistry
        );

        // ==================== QUANTITES ====================

        Check("11 livres crees",
              books.size() == 11);

        Check("5 membres crees",
              members.size() == 5);

        Check("Compteur Book coherent",
              Book::GetLiveCount() == 11);

        Check("Compteur Member coherent",
              Member::GetLiveCount() == 5);

        // ==================== TYPES DE LIVRES ====================

        int physicalCount = 0;
        int ebookCount = 0;
        int audioCount = 0;

        bool duneFound = false;
        bool damagedFound = false;
        bool fondationFound = false;
        bool princeFound = false;

        for (const auto& book : books)
        {
            if (dynamic_cast<PhysicalBook*>(book.get()))
                ++physicalCount;

            if (dynamic_cast<EBook*>(book.get()))
                ++ebookCount;

            if (dynamic_cast<AudioBook*>(book.get()))
                ++audioCount;

            if (book->GetTitle() == "Dune")
            {
                duneFound = true;
            }

            if (book->GetTitle() == "Les Miserables" &&
                book->GetStateLabel() == "DamagedState")
            {
                damagedFound = true;
            }

            if (book->GetTitle() == "Fondation" &&
                dynamic_cast<EBook*>(book.get()))
            {
                fondationFound = true;
            }

            if (book->GetTitle() == "Le Petit Prince" &&
                dynamic_cast<AudioBook*>(book.get()))
            {
                princeFound = true;
            }
        }

        Check("5 livres papier",
              physicalCount == 5);

        Check("3 livres numeriques",
              ebookCount == 3);

        Check("3 livres audio",
              audioCount == 3);

        Check("Dune trouve",
              duneFound);

        Check("Livre endommage correctement initialise",
              damagedFound);

        Check("Fondation cree comme EBook",
              fondationFound);

        Check("Le Petit Prince cree comme AudioBook",
              princeFound);

        // ==================== TYPES DE MEMBRES ====================

        int studentCount = 0;
        int teacherCount = 0;

        bool marieFound = false;
        bool valereFound = false;

        for (const auto& member : members)
        {
            if (dynamic_cast<Student*>(member.get()))
                ++studentCount;

            if (dynamic_cast<Teacher*>(member.get()))
                ++teacherCount;

            if (member->GetName() == "Marie Tremblay" &&
                member->GetMaxBooks() == 2 &&
                member->WantsNotifications())
            {
                marieFound = true;
            }

            if (member->GetName() == "Valere Dubois" &&
                member->GetMaxBooks() == 3 &&
                !member->WantsNotifications())
            {
                valereFound = true;
            }
        }

        Check("3 etudiants crees",
              studentCount == 3);

        Check("2 enseignants crees",
              teacherCount == 2);

        Check("Marie correctement chargee",
              marieFound);

        Check("Valere correctement charge",
              valereFound);

        // ==================== FIN DE PORTEE ====================

        // Les unique_ptr detruiront automatiquement
        // les livres et les membres en fin de portee.
    }

    // ==================== DESTRUCTION ====================

    std::cout << "\n=== Verification memoire ===\n";

    Check("Tous les livres detruits",
          Book::GetLiveCount() == 0);

    Check("Tous les membres detruits",
          Member::GetLiveCount() == 0);

    // ==================== RESULTATS ====================

    std::cout << "\nTests reussis : " << passed << '\n';
    std::cout << "Tests echoues : " << failed << '\n';

    return failed == 0 ? 0 : 1;
}
