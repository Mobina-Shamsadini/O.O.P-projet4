
#include <iostream>
#include <string>

#include "Books/Book.h"
#include "Books/PhysicalBook.h"
#include "Books/EBook.h"
#include "Books/AudioBook.h"

// Compteurs des tests.
int passed = 0;
int failed = 0;

// Verifie qu'une condition correspond au resultat attendu.
void Check(const std::string& description, bool condition)
{
    if (condition)
    {
        std::cout << "[OK] " << description << '\n';
        ++passed;
    }
    else
    {
        std::cout << "[ECHEC] " << description << '\n';
        ++failed;
    }
}

int main()
{
    std::string output;

    std::cout << "=== TESTS DU SYSTEME BOOK ===\n";

    Check("Compteur initial a zero",
          Book::GetLiveCount() == 0);

    {
        // ======================================
        // TEST 1 : PHYSICALBOOK
        // ======================================

        std::cout << "\n=== PhysicalBook ===\n";

        PhysicalBook dune(
            "Dune", "Frank Herbert", "SF-12");

        Check("Etat initial disponible",
              dune.GetStateLabel() == "AvailableState");

        Check("Premier emprunt accepte",
              dune.Checkout(output));

        Check("Transition vers CheckedOutState",
              dune.GetStateLabel() == "CheckedOutState");

        Check("Deuxieme emprunt refuse",
              !dune.Checkout(output));

        Check("Retour accepte",
              dune.Return(output));

        Check("Retour vers AvailableState",
              dune.GetStateLabel() == "AvailableState");

        Check("Retour supplementaire refuse",
              !dune.Return(output));

        // ======================================
        // TEST 2 : LIVRE ENDOMMAGE
        // ======================================

        std::cout << "\n=== PhysicalBook endommage ===\n";

        PhysicalBook damaged(
            "Les Miserables", "Victor Hugo",
            "CL-03", true);

        Check("Etat initial DamagedState",
              damaged.GetStateLabel() == "DamagedState");

        Check("Emprunt refuse",
              !damaged.Checkout(output));

        Check("Reservation refusee",
              !damaged.Reserve(output));

        Check("Retour refuse",
              !damaged.Return(output));

        // ======================================
        // TEST 3 : EBOOK
        // ======================================

        std::cout << "\n=== EBook ===\n";

        EBook ebook(
            "Fondation", "Isaac Asimov",
            "https://exemple.ca/fondation", 4);

        Check("Premier pret numerique",
              ebook.Checkout(output));

        Check("Deuxieme pret numerique",
              ebook.Checkout(output));

        Check("Deux emprunts actifs",
              ebook.GetActiveLoans() == 2);

        Check("EBook reste disponible",
              ebook.IsAvailable(output));

        Check("EBook reste en AvailableState",
              ebook.GetStateLabel() == "AvailableState");

        Check("Premier retour numerique",
              ebook.Return(output));

        Check("Un emprunt reste",
              ebook.GetActiveLoans() == 1);

        Check("Deuxieme retour numerique",
              ebook.Return(output));

        Check("Compteur revenu a zero",
              ebook.GetActiveLoans() == 0);

        Check("Retour supplementaire refuse",
              !ebook.Return(output));

        // ======================================
        // TEST 4 : AUDIOBOOK
        // ======================================

        std::cout << "\n=== AudioBook ===\n";

        AudioBook audio(
            "Le Petit Prince",
            "Antoine de Saint-Exupery",
            "Bernard Giraudeau",
            96, 2);

        Check("Premier emprunt audio",
              audio.Checkout(output));

        Check("Une licence occupee",
              audio.GetActiveListeners() == 1);

        Check("Encore disponible",
              audio.IsAvailable(output));

        Check("Deuxieme emprunt audio",
              audio.Checkout(output));

        Check("Deux licences occupees",
              audio.GetActiveListeners() == 2);

        Check("Etat CheckedOutState",
              audio.GetStateLabel() == "CheckedOutState");

        Check("Troisieme emprunt refuse",
              !audio.Checkout(output));

        Check("Retour audio accepte",
              audio.Return(output));

        Check("Une licence liberee",
              audio.GetActiveListeners() == 1);

        Check("Audio redevient disponible",
              audio.IsAvailable(output));

        Check("Dernier retour audio",
              audio.Return(output));

        Check("Aucune licence occupee",
              audio.GetActiveListeners() == 0);

        Check("Retour supplementaire refuse",
              !audio.Return(output));

        // ======================================
        // TEST 5 : RESERVATION
        // ======================================

        std::cout << "\n=== Reservation ===\n";

        PhysicalBook reserved(
            "1984", "George Orwell", "B-01");

        Check("Reservation acceptee",
              reserved.Reserve(output));

        Check("Etat ReservedState",
              reserved.GetStateLabel() == "ReservedState");

        Check("Deuxieme reservation refusee",
              !reserved.Reserve(output));

        Check("Retour avant emprunt refuse",
              !reserved.Return(output));

        // Une reservation ne doit pas rendre le
        // livre disponible a tout autre membre.
        Check("Livre reserve non disponible en general",
              !reserved.IsAvailable(output));

        // La transition de reservation vers emprunt
        // reste autorisee par le patron State.
        Check("Emprunt apres reservation",
              reserved.Checkout(output));

        Check("Etat CheckedOutState apres emprunt",
              reserved.GetStateLabel() == "CheckedOutState");

        Check("Retour apres emprunt",
              reserved.Return(output));

        // ======================================
        // TEST 6 : RESERVATION AUDIO
        // ======================================

        std::cout << "\n=== Reservation AudioBook ===\n";

        AudioBook reservedAudio(
            "Livre audio reserve",
            "Auteur Test",
            "Narrateur Test", 60, 2);

        Check("Premiere licence audio empruntee",
              reservedAudio.Checkout(output));

        Check("Reservation audio acceptee",
              reservedAudio.Reserve(output));

        Check("Audio dans ReservedState",
              reservedAudio.GetStateLabel() == "ReservedState");

        Check("Retour de la licence active",
              reservedAudio.Return(output));

        Check("Aucune licence audio active",
              reservedAudio.GetActiveListeners() == 0);

        Check("Reservation conservee apres retour",
              reservedAudio.GetStateLabel() == "ReservedState");

        Check("Emprunt depuis ReservedState",
              reservedAudio.Checkout(output));

        Check("Retour de cet emprunt",
              reservedAudio.Return(output));

        // ======================================
        // VERIFICATION DES COMPTEURS
        // ======================================

        Check("Six livres actuellement vivants",
              Book::GetLiveCount() == 6);
    }

    std::cout << "\n=== Verification finale ===\n";

    Check("Tous les livres detruits",
          Book::GetLiveCount() == 0);

    std::cout << "\nTests reussis : " << passed << '\n';
    std::cout << "Tests echoues : " << failed << '\n';

    return failed == 0 ? 0 : 1;
}
//
// Created by Mobina Shamsadini on 2026-11-19.
//
