
#include <iostream>
#include <string>
#include <vector>

#include "Factories/MemberFactoryRegistry.h"
#include "Members/Member.h"
#include "Members/Student.h"
#include "Members/Teacher.h"

// Compteurs des tests.
int passed = 0;
int failed = 0;

// Verifie une condition et affiche son resultat.
void Check(const std::string& description, bool condition)
{
    if (condition)
    {
        std::cout << "[OK] " << description << '\n';
        ++passed;
    }
    else
    {
        std::cout << "[ECHEC] " << description << '\n';
        ++failed;
    }
}

int main()
{
    std::cout << "=== TESTS MEMBER FACTORY REGISTRY ===\n";

    const MemberFactoryRegistry registry;

    Check("Compteur initial a zero",
          Member::GetLiveCount() == 0);

    // ==================== STUDENT ====================

    std::cout << "\n=== Student ===\n";

    auto student = registry.Create({
        "student",
        "Marie Tremblay",
        "20240001",
        "informatique",
        "oui"
    });

    Check("Creation Student",
          student != nullptr);

    Check("Type dynamique Student",
          dynamic_cast<Student*>(student.get()) != nullptr);

    Check("Nom correct",
          student && student->GetName() == "Marie Tremblay");

    Check("Type Etudiant",
          student && student->GetTypeLabel() == "Etudiant");

    Check("Limite de deux livres",
          student && student->GetMaxBooks() == 2);

    Check("Notifications activees",
          student && student->WantsNotifications());

    // ==================== TEACHER ====================

    std::cout << "\n=== Teacher ===\n";

    auto teacher = registry.Create({
        "teacher",
        "Valere Dubois",
        "10001",
        "informatique",
        "non"
    });

    Check("Creation Teacher",
          teacher != nullptr);

    Check("Type dynamique Teacher",
          dynamic_cast<Teacher*>(teacher.get()) != nullptr);

    Check("Type Enseignant",
          teacher && teacher->GetTypeLabel() == "Enseignant");

    Check("Limite de trois livres",
          teacher && teacher->GetMaxBooks() == 3);

    Check("Notifications desactivees",
          teacher && !teacher->WantsNotifications());

    // ==================== DONNEES INVALIDES ====================

    std::cout << "\n=== Donnees invalides ===\n";

    Check("Type inconnu refuse",
          registry.Create({
              "visitor", "Nom", "100", "info", "oui"
          }) == nullptr);

    Check("Ligne vide refusee",
          registry.Create({}) == nullptr);

    Check("Identifiant non numerique refuse",
          registry.Create({
              "student", "Nom", "abc", "info", "oui"
          }) == nullptr);

    Check("Identifiant negatif refuse",
          registry.Create({
              "teacher", "Nom", "-5", "info", "non"
          }) == nullptr);

    Check("Notifications invalides refusees",
          registry.Create({
              "student", "Nom", "123", "info", "maybe"
          }) == nullptr);

    Check("Nom vide refuse",
          registry.Create({
              "teacher", "", "123", "info", "oui"
          }) == nullptr);

    Check("Champ manquant refuse",
          registry.Create({
              "student", "Nom", "123", "info"
          }) == nullptr);

    // ==================== DESTRUCTION ====================

    std::cout << "\n=== Compteurs ===\n";

    Check("Deux membres vivants",
          Member::GetLiveCount() == 2);

    student.reset();
    teacher.reset();

    Check("Tous les membres detruits",
          Member::GetLiveCount() == 0);

    // ==================== RESULTAT ====================

    std::cout << "\nTests reussis : " << passed << '\n';
    std::cout << "Tests echoues : " << failed << '\n';

    return failed == 0 ? 0 : 1;
}
