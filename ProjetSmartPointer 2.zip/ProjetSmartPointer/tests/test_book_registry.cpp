
#include <iostream>
#include <string>
#include <vector>

#include "Books/Book.h"
#include "Books/PhysicalBook.h"
#include "Books/EBook.h"
#include "Books/AudioBook.h"
#include "Factories/BookFactoryRegistry.h"

// Compteurs des tests.
int passed = 0;
int failed = 0;

// Verifie une condition et affiche son resultat.
void Check(const std::string& description, bool condition)
{
    if (condition)
    {
        std::cout << "[OK] " << description << '\n';
        ++passed;
    }
    else
    {
        std::cout << "[ECHEC] " << description << '\n';
        ++failed;
    }
}

int main()
{
    std::cout << "=== TESTS BOOK FACTORY REGISTRY ===\n";

    // Le registre doit fonctionner avec un appel const.
    const BookFactoryRegistry registry;

    // ==================== LIVRE PAPIER ====================

    auto physical = registry.Create({
        "physical", "Dune", "Frank Herbert",
        "SF-12", "bon"
    });

    Check("Creation PhysicalBook",
          physical != nullptr);

    Check("Type dynamique PhysicalBook",
          dynamic_cast<PhysicalBook*>(physical.get()) != nullptr);

    Check("Etat initial PhysicalBook",
          physical &&
          physical->GetStateLabel() == "AvailableState");

    // ==================== LIVRE NUMERIQUE ====================

    auto ebook = registry.Create({
        "ebook", "Fondation", "Isaac Asimov",
        "https://exemple.ca/fondation", "4"
    });

    Check("Creation EBook",
          ebook != nullptr);

    Check("Type dynamique EBook",
          dynamic_cast<EBook*>(ebook.get()) != nullptr);

    // ==================== LIVRE AUDIO ====================

    auto audio = registry.Create({
        "audio", "Le Petit Prince",
        "Antoine de Saint-Exupery",
        "Bernard Giraudeau", "96", "2"
    });

    Check("Creation AudioBook",
          audio != nullptr);

    Check("Type dynamique AudioBook",
          dynamic_cast<AudioBook*>(audio.get()) != nullptr);

    // ==================== LIGNES INVALIDES ====================

    Check("Type inconnu refuse",
          registry.Create({
              "magazine", "Titre", "Auteur"
          }) == nullptr);

    Check("Ligne vide refusee",
          registry.Create({}) == nullptr);

    Check("Livre papier invalide refuse",
          registry.Create({
              "physical", "Livre", "Auteur",
              "A-01", "inconnu"
          }) == nullptr);

    Check("EBook invalide refuse",
          registry.Create({
              "ebook", "Livre", "Auteur",
              "https://exemple.ca", "abc"
          }) == nullptr);

    Check("AudioBook invalide refuse",
          registry.Create({
              "audio", "Livre", "Auteur",
              "Narrateur", "96", "0"
          }) == nullptr);

    // ==================== COMPTEUR ====================

    Check("Trois livres vivants",
          Book::GetLiveCount() == 3);

    physical.reset();
    ebook.reset();
    audio.reset();

    Check("Tous les livres detruits",
          Book::GetLiveCount() == 0);

    // ==================== RESULTATS ====================

    std::cout << "\nTests reussis : " << passed << '\n';
    std::cout << "Tests echoues : " << failed << '\n';

    return failed == 0 ? 0 : 1;
}
