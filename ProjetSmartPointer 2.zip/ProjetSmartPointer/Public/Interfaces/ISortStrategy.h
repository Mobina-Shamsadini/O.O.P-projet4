
#pragma once

#include <string>

class Book;

// Interface du patron Strategy.
//
// Chaque strategie definit un critere de comparaison
// permettant de trier les livres du catalogue.
//
// Library utilise une strategie sans en etre proprietaire.
class ISortStrategy
{
public:
    // Destructeur virtuel pour permettre le polymorphisme.
    virtual ~ISortStrategy() = default;

    // Compare deux livres selon le critere choisi.
    //
    // Retourne true si le livre a doit preceder
    // le livre b dans le catalogue.
    virtual bool Compare(
        const Book& a,
        const Book& b
    ) const = 0;

    // Retourne le nom du critere de tri.
    //
    // Valeurs attendues dans le journal :
    // "titre", "auteur" ou "etat".
    virtual std::string GetName() const = 0;
};
