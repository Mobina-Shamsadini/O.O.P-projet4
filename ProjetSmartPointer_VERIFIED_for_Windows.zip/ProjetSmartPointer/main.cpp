// =====================================================================
//  main.cpp - Une journee a la bibliotheque
//
//  CE FICHIER NE DOIT PAS ETRE MODIFIE.
//  Votre travail : faire en sorte que ce programme compile, s'execute
//  sans erreur, que toutes les verifications affichent [OK] et que
//  library.log soit identique a library_attendu.log.
// =====================================================================

#include <iostream>
#include <memory>
#include <string>
#include <utility>

#include "Books/Book.h"
#include "Commands/BorrowCommand.h"
#include "Commands/Cart.h"
#include "Commands/ReturnCommand.h"
#include "Factories/BookFactoryRegistry.h"
#include "Factories/MemberFactoryRegistry.h"
#include "Library.h"
#include "LibraryLogger.h"
#include "Loading/CsvLoader.h"
#include "Members/Member.h"
#include "Strategies/SortByAuthor.h"
#include "Strategies/SortByState.h"
#include "Strategies/SortByTitle.h"

namespace TOOL {
    int checks = 0;
    int failures = 0;

    void Titre(const std::string &texte) {
        std::cout << "\n=== " << texte << " ===\n";
    }

    // Affiche le resultat d'une verification ; les echecs sont comptes.
    // description est une reference : dans
    //     Verifier(cart.Undo(output), output);
    // elle designe output, lu ici APRES que Undo() l'a rempli.
    void Verifier(bool condition, const std::string &description) {
        checks++;
        if (condition) {
            std::cout << "  [OK] " << description << "\n";
        } else {
            failures++;
            std::cout << "  [ECHEC] " << description << "\n";
        }
    }

    // Trie avec la strategie recue, puis journalise l'ordre obtenu.
    void Trier(Library &library, const ISortStrategy &strategy) {
        library.SetSortStrategy(strategy);
        library.SortBooks();

        std::string order;
        for (const std::shared_ptr<Book> &book: library.GetBooks().GetItems()) {
            if (!order.empty())
                order += ", ";
            order += book->GetTitle();
        }
        LibraryLogger::GetInstance().Log("[TRI] " + strategy.GetName() + " : " + order);
    }

    std::string PremierTitre(const Library &library) {
        std::string position;
        const Book *first = library.GetBooks().Get(0, position);
        return first == nullptr ? "" : first->GetTitle();
    }
}

int main() {
    {
        // Strategies : declarees AVANT library, elles existent
        // tant que library peut s'en servir.
        const SortByTitle byTitle;
        const SortByAuthor byAuthor;
        const SortByState byState;

        Library library;
        LibraryLogger &log = LibraryLogger::GetInstance();

        // Chaque methode qui reussit ou echoue ecrit ici ce qui s'est passe :
        // main affiche ce texte, mais ne l'ecrit jamais lui-meme.
        std::string output;

        // ==============================================================
        TOOL::Titre("Phase 1 - Ouverture : chargement des fichiers (Factory Method)");

        // Un fichier absent ne doit pas arreter le programme.
        const BookFactoryRegistry bookRegistry;
        const std::vector<std::unique_ptr<Book>> missing = CsvLoader::LoadCsv("inventaire.csv", bookRegistry);
        TOOL::Verifier(missing.empty(), "un fichier absent ne cree aucun livre");

        // Les lignes invalides sont ignorees, les autres deviennent des objets.
        // Le livre est journalise AVANT d'etre cede : apres std::move, book est vide.
        for (std::unique_ptr<Book> &book: CsvLoader::LoadCsv("books.csv", bookRegistry)) {
            log.Log("[CHARGEMENT] " + book->GetTitle() + " (" + book->GetTypeLabel() + ")");
            library.AddBook(std::move(book));
        }

        const MemberFactoryRegistry memberRegistry;
        TOOL::Verifier(CsvLoader::LoadCsv("membres_2025.csv", memberRegistry).empty(),
                       "un fichier de membres absent ne cree aucun membre");
        for (std::unique_ptr<Member> &member: CsvLoader::LoadCsv("members.csv", memberRegistry)) {
            log.Log("[CHARGEMENT] " + member->GetName() + " (" + member->GetTypeLabel() + ")");
            library.AddMember(std::move(member));
        }

        TOOL::Verifier(library.GetBookCount() == 11, std::to_string(library.GetBookCount())+" livres valides charges");
        TOOL::Verifier(library.GetMemberCount() == 5, std::to_string(library.GetMemberCount())+" membres valides charges");
        TOOL::Verifier(library.FindBook("Livre inconnu") == nullptr, "type de livre inconnu ignore");
        TOOL::Verifier(library.FindBook("Fichier corrompu") == nullptr, "nombre invalide ignore");
        TOOL::Verifier(library.FindBook("Sans licence") == nullptr, "livre audio sans licence ignore");
        TOOL::Verifier(library.FindBook("Etat inconnu") == nullptr, "etat de livre inconnu ignore");
        TOOL::Verifier(library.FindMember("Robert Roy") == nullptr, "type de membre inconnu ignore");
        TOOL::Verifier(library.FindMember("Julie Bouchard") == nullptr, "preference invalide ignoree");

        // Consultation : la bibliotheque garde ses livres et ses membres ;
        // ces pointeurs ne font que les designer (aucun delete, aucune propriete).
        Member *marie = library.FindMember("Marie Tremblay");
        Member *hugo = library.FindMember("Hugo Lambert");
        Member *valere = library.FindMember("Valere Dubois");
        Member *lea = library.FindMember("Lea Gagnon");
        Member *sophie = library.FindMember("Sophie Martin");

        Book *dune = library.FindBook("Dune");
        Book *miserables = library.FindBook("Les Miserables");
        Book *seigneur = library.FindBook("Le Seigneur des anneaux");
        Book *monteCristo = library.FindBook("Le Comte de Monte-Cristo");
        Book *notreDame = library.FindBook("Notre-Dame de Paris");
        Book *fondation = library.FindBook("Fondation");
        Book *orwell = library.FindBook("1984");
        Book *huxley = library.FindBook("Le Meilleur des mondes");
        Book *petitPrince = library.FindBook("Le Petit Prince");
        Book *etranger = library.FindBook("L'Etranger");
        Book *mousquetaires = library.FindBook("Les Trois Mousquetaires");

        if (marie == nullptr || hugo == nullptr || valere == nullptr || lea == nullptr
            || sophie == nullptr || dune == nullptr || miserables == nullptr
            || seigneur == nullptr || monteCristo == nullptr || fondation == nullptr
            || orwell == nullptr || huxley == nullptr || petitPrince == nullptr
            || etranger == nullptr || notreDame == nullptr || mousquetaires == nullptr) {
            std::cout << "\nChargement incomplet : le scenario ne peut pas continuer.\n";
            return 1;
        }

        // ==============================================================
        TOOL::Titre("Phase 2 - Catalogue : par titre, par auteur, par etat (Strategy)");
        library.SortBooks();
        TOOL::Verifier(TOOL::PremierTitre(library) == "Dune",
                       "sans strategie choisie, SortBooks() ne change rien");
        TOOL::Trier(library, byTitle);
        library.DisplayCatalog();
        TOOL::Verifier(TOOL::PremierTitre(library) == "1984", "tri par titre : 1984 en tete");

        TOOL::Trier(library, byAuthor);
        library.DisplayCatalog();
        library.DisplayMembers();
        TOOL::Verifier(TOOL::PremierTitre(library) == "L'Etranger",
                       "tri par auteur : Albert Camus en tete");

        TOOL::Trier(library, byState);
        library.DisplayCatalog();
        library.DisplayMembers();
        TOOL::Verifier(TOOL::PremierTitre(library) == "Les Miserables",
                       "tri par etat : le livre endommage en tete");

        // ==============================================================
        TOOL::Titre("Phase 3 - Matinee : emprunts (Command, State, Observer)");

        // Livre papier : un seul exemplaire.
        TOOL::Verifier(marie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *marie, *dune), output), output);
        TOOL::Verifier(!marie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *marie, *dune), output), output);

        // Livre sorti : liste d'attente (Observer), selon la preference du membre.
        TOOL::Verifier(!hugo->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *hugo, *dune), output), output);
        TOOL::Verifier(!hugo->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *hugo, *dune), output), output);
        TOOL::Verifier(!valere->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *valere, *dune), output), output);

        // Livre endommage : refuse, et attendre ne servirait a rien.
        TOOL::Verifier(!lea->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *lea, *miserables), output), output);
        TOOL::Verifier(!sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *miserables), output), output);

        // Livre numerique : plusieurs lecteurs en meme temps, mais une copie par membre.
        TOOL::Verifier(hugo->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *hugo, *fondation), output), output);
        TOOL::Verifier(lea->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *lea, *fondation), output), output);
        TOOL::Verifier(!hugo->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *hugo, *fondation), output), output);
        TOOL::Verifier(fondation->IsAvailable(output), output);

        // Livre audio a une licence : sorti des le premier emprunt.
        TOOL::Verifier(valere->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *valere, *etranger), output), output);
        TOOL::Verifier(!marie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *marie, *etranger), output), output);
        TOOL::Verifier(!sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *etranger), output), output);

        // Livre audio a deux licences : sorti au depart de la derniere.
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *petitPrince), output), output);
        TOOL::Verifier(petitPrince->IsAvailable(output), output);
        TOOL::Verifier(lea->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *lea, *petitPrince), output), output);
        TOOL::Verifier(!marie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *marie, *petitPrince), output), output);

        // Limite d'emprunts : un etudiant a droit a 2 livres.
        TOOL::Verifier(hugo->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *hugo, *orwell), output), output);
        TOOL::Verifier(!hugo->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *hugo, *huxley), output), output);
        TOOL::Verifier(!lea->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *lea, *dune), output), output);

        // Reservation : le livre est mis de cote au comptoir (State).
        TOOL::Verifier(seigneur->Reserve(output), output);
        TOOL::Verifier(!seigneur->Reserve(output), output);
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *seigneur), output), output);

        // ==============================================================
        TOOL::Titre("Phase 4 - Paniers en ligne (Command, Observer)");

        // Ajouter au panier ne change rien : le livre ne sort qu'a la validation.
        TOOL::Verifier(sophie->GetCart().Add(std::make_unique<BorrowCommand>(library, *sophie, *monteCristo), output), output);
        TOOL::Verifier(valere->GetCart().Add(std::make_unique<BorrowCommand>(library, *valere, *notreDame), output), output);
        TOOL::Verifier(valere->GetCart().Add(std::make_unique<BorrowCommand>(library, *valere, *monteCristo), output), output);
        TOOL::Verifier(valere->GetCart().Add(std::make_unique<BorrowCommand>(library, *valere, *mousquetaires), output), output);
        TOOL::Verifier(monteCristo->IsAvailable(output), output);

        // Retirer avant la validation : chacun dans son propre panier.
        TOOL::Verifier(sophie->GetCart().Add(std::make_unique<BorrowCommand>(library, *sophie, *huxley), output), output);
        TOOL::Verifier(sophie->GetCart().Cancel(output), output);
        TOOL::Verifier(valere->GetCart().Cancel(output), output);

        // Un panier ne reserve rien : le premier qui valide obtient le livre.
        TOOL::Verifier(valere->GetCart().Checkout(output) == 2, output);
        TOOL::Verifier(!valere->GetCart().Cancel(output), output);

        // Le livre de Sophie est parti : elle veut etre prevenue, elle attend.
        TOOL::Verifier(sophie->GetCart().Checkout(output) == 0, output);

        // Defaire un ordre passe : toutes ses operations, de la derniere a la premiere.
        TOOL::Verifier(valere->GetCart().Undo(output), output);

        // Un emprunt immediat se defait aussi.
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *monteCristo), output), output);
        TOOL::Verifier(sophie->GetCart().Undo(output), output);

        // ==============================================================
        TOOL::Titre("Phase 5 - Apres-midi : retours (Command, State, Observer)");

        // Retours impossibles.
        TOOL::Verifier(!hugo->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *hugo, *dune), output), output);
        TOOL::Verifier(!valere->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *valere, *dune), output), output);

        // Retour d'un livre attendu : un seul avis, meme si Hugo l'a demande deux fois.
        TOOL::Verifier(marie->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *marie, *dune), output), output);

        // Prevenu, mais a sa limite : Hugo doit d'abord rendre un livre.
        TOOL::Verifier(!hugo->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *hugo, *dune), output), output);
        TOOL::Verifier(hugo->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *hugo, *orwell), output), output);
        TOOL::Verifier(hugo->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *hugo, *dune), output), output);

        // Deux personnes attendent le meme livre : les deux sont prevenues.
        TOOL::Verifier(valere->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *valere, *etranger), output), output);
        TOOL::Verifier(marie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *marie, *etranger), output), output);
        TOOL::Verifier(!valere->GetCart().Undo(output), output);
        TOOL::Verifier(!sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *etranger), output), output);
        library.Unsubscribe(*etranger, *sophie);
        TOOL::Verifier(!library.IsWaiting(*etranger, *sophie, output), output);

        // Livre audio : la licence qui revient rend le titre disponible.
        TOOL::Verifier(lea->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *lea, *petitPrince), output), output);
        TOOL::Verifier(marie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *marie, *petitPrince), output), output);
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *sophie, *petitPrince), output), output);

        // Un retour peut attendre dans un panier, puis etre retire.
        TOOL::Verifier(lea->GetCart().Add(std::make_unique<ReturnCommand>(library, *lea, *fondation), output), output);
        TOOL::Verifier(lea->GetCart().Cancel(output), output);
        TOOL::Verifier(lea->GetCart().Checkout(output) == 0, output);

        // Un retour passe se defait : le livre revient au membre.
        TOOL::Verifier(lea->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *lea, *fondation), output), output);
        TOOL::Verifier(lea->GetCart().Undo(output), output);

        // Un livre deja rendu ne se rend pas deux fois.
        TOOL::Verifier(!valere->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *valere, *etranger), output), output);

        // ==============================================================
        TOOL::Titre("Phase 6 - Fermeture : cas limites (State, Command, Observer)");

        // Un panier n'accepte que les commandes de son proprietaire.
        TOOL::Verifier(!hugo->GetCart().Add(std::make_unique<BorrowCommand>(library, *marie, *huxley), output), output);
        TOOL::Verifier(!hugo->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *marie, *etranger), output), output);

        // Se retirer d'une liste ou l'on n'est pas : rien ne se passe.
        library.Unsubscribe(*notreDame, *hugo);
        TOOL::Verifier(!library.IsWaiting(*notreDame, *hugo, output), output);

        // Chaque etat refuse ce que son tableau refuse (appels directs au Contexte).
        TOOL::Verifier(!notreDame->Return(output), output);
        TOOL::Verifier(!dune->Reserve(output), output);
        TOOL::Verifier(!miserables->Reserve(output), output);
        TOOL::Verifier(!miserables->Return(output), output);
        TOOL::Verifier(notreDame->Reserve(output), output);
        TOOL::Verifier(!notreDame->Return(output), output);
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *notreDame), output), output);

        // Deux membres attendent Dune ; Marie change d'avis, Sophie reste.
        TOOL::Verifier(marie->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *marie, *petitPrince), output), output);
        TOOL::Verifier(!marie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *marie, *dune), output), output);
        TOOL::Verifier(!sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *dune), output), output);
        library.Unsubscribe(*dune, *marie);
        TOOL::Verifier(!library.IsWaiting(*dune, *marie, output), output);
        TOOL::Verifier(hugo->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *hugo, *dune), output), output);

        // Annuler un retour quand le livre est deja reparti : le membre ne le
        // reprend pas, mais il est mis en attente s'il souhaite etre prevenu.
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *dune), output), output);
        TOOL::Verifier(!hugo->GetCart().Undo(output), output);
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *sophie, *dune), output), output);

        // Library refuse le retour d'un livre que le membre n'a pas.
        TOOL::Verifier(!library.ReturnBook(*hugo, *huxley, output), output);

        // Un livre audio ou numerique sans emprunt en cours ne se rend pas.
        TOOL::Verifier(!mousquetaires->Return(output), output);
        TOOL::Verifier(!huxley->Return(output), output);

        // Un livre audio reserve pendant une ecoute : le retour de la licence
        // ne le rend pas disponible, personne n'est prevenu.
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<BorrowCommand>(library, *sophie, *mousquetaires), output), output);
        TOOL::Verifier(mousquetaires->Reserve(output), output);
        TOOL::Verifier(sophie->GetCart().ExecuteNow(std::make_unique<ReturnCommand>(library, *sophie, *mousquetaires), output), output);
        TOOL::Verifier(!mousquetaires->IsAvailable(output), output);

        // Deux livres endommages : aucun ne passe avant l'autre.
        TOOL::Verifier(!byState.Before(*miserables, *miserables, output), output);

        // Le catalogue refuse un indice hors limites.
        TOOL::Verifier(library.GetBooks().Get(-1, output) == nullptr, output);
        TOOL::Verifier(library.GetBooks().Get(library.GetBookCount(), output) == nullptr, output);

        // Lea annule toute sa journee, ordre par ordre, jusqu'au premier.
        while (lea->GetCart().Undo(output)){}

        TOOL::Verifier(!lea->GetCart().Undo(output), output);

        // Un panier abandonne : ses commandes sont detruites avec le membre.
        TOOL::Verifier(marie->GetCart().Add(std::make_unique<BorrowCommand>(library, *marie, *huxley), output), output);

        library.DisplayCatalog();
        library.DisplayMembers();

        TOOL::Titre("Sortie de portee");
    }

    TOOL::Titre("Verification de l'equilibre");
    std::cout << "Livres vivants : " << Book::GetLiveCount() << "\n";
    std::cout << "Membres vivants : " << Member::GetLiveCount() << "\n";

    std::cout << "\nVerifications reussies : " << TOOL::checks - TOOL::failures
              << " / " << TOOL::checks << "\n";
    return TOOL::failures == 0 ? 0 : 1;
}
