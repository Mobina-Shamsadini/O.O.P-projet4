cmake_minimum_required(VERSION 3.16)
project(Bibliotheque LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

file(GLOB_RECURSE SOURCES CONFIGURE_DEPENDS Private/*.cpp)
add_executable(build main.cpp ${SOURCES})

# Seul Public est expose : les inclusions s'ecrivent avec leur
# sous-dossier, par exemple #include "Books/Book.h".
target_include_directories(build PRIVATE Public)

if (MSVC)
    target_compile_options(build PRIVATE /W4)
else ()
    target_compile_options(build PRIVATE -Wall -Wextra -Wpedantic)
endif ()

# Les fichiers CSV sont lus depuis le dossier d'execution.
configure_file(books.csv ${CMAKE_BINARY_DIR}/books.csv COPYONLY)
configure_file(members.csv ${CMAKE_BINARY_DIR}/members.csv COPYONLY)
configure_file(library_attendu.log ${CMAKE_BINARY_DIR}/library_attendu.log COPYONLY)
