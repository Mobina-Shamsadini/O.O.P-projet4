#pragma once

#include <fstream>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "Factories/FactoryRegistry.h"
#include "LibraryLogger.h"

// Classe outil : aucun attribut, seulement des methodes statiques.
class CsvLoader {
public:
    // "Dune,Frank Herbert" -> {"Dune", "Frank Herbert"}
    static std::vector<std::string> SplitCsv(const std::string &line);

    // Convertit un champ en entier strictement positif.
    // Retourne false si le texte est vide ou contient autre chose que des
    // chiffres : une ligne invalide ne doit jamais arreter le programme.
    static bool ToInt(const std::string &text, int &value);

    // Lit un fichier CSV et cree un objet par ligne, avec la fabrique que le
    // registre associe au premier champ. Aucune classe concrete ici.
    // Retourne les objets crees : l'appelant en devient proprietaire.
    template<typename T>
    static std::vector<std::unique_ptr<T>> LoadCsv(const std::string &path,
                                    const FactoryRegistry<T> &registry);
};

// Un template se definit dans le .h : le compilateur doit voir son code
// la ou il est utilise. SplitCsv(), elle, est definie dans CsvLoader.cpp.
template<typename T>
std::vector<std::unique_ptr<T>> CsvLoader::LoadCsv(const std::string &path,
                                    const FactoryRegistry<T> &registry) {
    LibraryLogger &log = LibraryLogger::GetInstance();
    std::vector<std::unique_ptr<T>> created;
    std::ifstream file{path};
    if (!file) {
        log.Log("[ERREUR] fichier introuvable : " + path);
        return created;
    }

    std::string line;
    std::getline(file, line);                  // ligne d'en-tete
    while (std::getline(file, line)) {
        // Fichier enregistre sous Windows : chaque ligne finit par '\r'.
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        if (line.empty())
            continue;
        const auto fields = SplitCsv(line);
        std::unique_ptr<T> item = registry.Create(fields);
        if (item == nullptr)
            log.Log("[IGNORE] " + line);
        else
            created.push_back(std::move(item));
    }
    return created;
}
