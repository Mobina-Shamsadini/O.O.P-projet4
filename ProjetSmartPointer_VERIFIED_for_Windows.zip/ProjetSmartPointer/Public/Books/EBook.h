
#pragma once

#include <string>

#include "Book.h"

// Livre numerique : nombre illimite d'emprunts simultanes.
//
// Le livre reste disponible meme lorsqu'il est emprunte.
// Le compteur activeLoans_ indique le nombre de prets en cours.
class EBook final : public Book
{
private:
    // Adresse de telechargement du livre.
    std::string downloadUrl_;

    // Taille du fichier en megaoctets.
    int fileSizeMb_;

    // Nombre d'emprunts actuellement actifs.
    int activeLoans_ = 0;

public:
    // Constructeur du livre numerique.
    EBook(std::string title,
          std::string author,
          std::string downloadUrl,
          int fileSizeMb);

    // ==================== ACCESSEURS ====================

    const std::string& GetDownloadUrl() const;
    int GetFileSizeMb() const;
    int GetActiveLoans() const;

    // Nom du type concret.
    std::string GetTypeLabel() const override;

    // ==================== EMPRUNT ET RETOUR ====================

    // Autorise plusieurs emprunts simultanes.
    bool Checkout(std::string& output) override;

    // Diminue le compteur si un emprunt existe.
    bool Return(std::string& output) override;

    // Le livre numerique reste toujours disponible.
    bool IsAvailable(std::string& output) const override;

    // ==================== AFFICHAGE ====================

    void Display() const override;
};

