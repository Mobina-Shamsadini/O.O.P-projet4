
#pragma once

#include <string>

#include "Book.h"

// Livre papier : un seul exemplaire peut etre emprunte a la fois.
// Un livre endommage ne peut pas etre emprunte ou reserve.
class PhysicalBook final : public Book
{
private:
    // Emplacement du livre dans la bibliotheque.
    std::string shelf_;

public:
    // Construit un livre papier.
    // damaged indique si le livre est initialement endommage.
    PhysicalBook(std::string title,
                 std::string author,
                 std::string shelf,
                 bool damaged = false);

    // Accesseur propre aux livres papier.
    const std::string& GetShelf() const;

    // Nom du type concret.
    std::string GetTypeLabel() const override;

    // Regles d'emprunt et de retour d'un exemplaire unique.
    bool Checkout(std::string& output) override;
    bool Return(std::string& output) override;

    // Affichage polymorphe.
    void Display() const override;
};
//
// Created by Mobina Shamsadini on 2026-11-19.
//

#ifndef BIBLIOTHEQUE_PHYSICALBOOK_H
#define BIBLIOTHEQUE_PHYSICALBOOK_H

#endif //BIBLIOTHEQUE_PHYSICALBOOK_H
