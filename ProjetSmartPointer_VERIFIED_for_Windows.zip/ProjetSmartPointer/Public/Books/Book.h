
#pragma once

#include <string>

#include "Interfaces/IDisplayable.h"
#include "Interfaces/IBookState.h"

// Classe de base abstraite de tous les livres.
//
// Les classes derivees definissent leurs propres regles
// d'emprunt et de retour.
//
// Le patron State gere les transitions entre les etats.
// Le livre applique ces transitions et les journalise.
class Book : public IDisplayable
{
private:
    std::string title_;
    std::string author_;

    // Etat courant : pointeur non proprietaire.
    // Les etats sont des Singletons partages entre les livres.
    const IBookState* state_;

    // Compteur des livres actuellement vivants.
    static int liveCount_;

protected:
    // Constructeur reserve aux classes derivees.
    Book(std::string title,
         std::string author,
         const IBookState& initialState);

    // Applique une transition autorisee et la journalise.
    // Un pointeur nul signifie que la transition est refusee.
    bool ApplyTransition(const IBookState* nextState);

public:
    // Destructeur virtuel : destruction correcte des enfants.
    ~Book() override;

    // Copie et deplacement interdits.
    Book(const Book&) = delete;
    Book& operator=(const Book&) = delete;
    Book(Book&&) = delete;
    Book& operator=(Book&&) = delete;

    // ==================== ACCESSEURS ====================

    const std::string& GetTitle() const;
    const std::string& GetAuthor() const;

    // Acces en lecture a l'etat courant.
    const IBookState& GetState() const;
    std::string GetStateLabel() const;

    // Nom du type concret : Papier, Numerique ou Audio.
    virtual std::string GetTypeLabel() const = 0;

    // Nombre de livres vivants.
    static int GetLiveCount();

    // ==================== OPERATIONS ====================

    // Tente un emprunt selon les regles du type de livre.
    virtual bool Checkout(std::string& output);

    // Tente un retour selon les regles du type de livre.
    virtual bool Return(std::string& output);

    // Tente de reserver le livre.
    virtual bool Reserve(std::string& output);

    // Verifie la disponibilite et explique le resultat.
    virtual bool IsAvailable(std::string& output) const;

    // ==================== AFFICHAGE ====================

    // Chaque enfant possede son propre format d'affichage.
    void Display() const override = 0;
};

#ifndef BIBLIOTHEQUE_BOOK_H
#define BIBLIOTHEQUE_BOOK_H

#endif //BIBLIOTHEQUE_BOOK_H
