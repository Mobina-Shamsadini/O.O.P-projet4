
#pragma once

#include <string>

#include "Book.h"

// Livre audio : nombre limite d'ecoutes simultanees.
//
// Le livre devient indisponible lorsque toutes les licences
// sont utilisees. Un retour libere une licence.
class AudioBook final : public Book
{
private:
    // Informations propres au livre audio.
    std::string narrator_;
    int durationMinutes_;
    int maxListeners_;

    // Nombre d'ecoutes actuellement actives.
    int activeListeners_ = 0;

public:
    // Constructeur du livre audio.
    AudioBook(std::string title,
              std::string author,
              std::string narrator,
              int durationMinutes,
              int maxListeners);

    // ==================== ACCESSEURS ====================

    const std::string& GetNarrator() const;
    int GetDurationMinutes() const;
    int GetMaxListeners() const;
    int GetActiveListeners() const;

    // ==================== TYPE ====================

    std::string GetTypeLabel() const override;

    // ==================== EMPRUNT ET RETOUR ====================

    bool Checkout(std::string& output) override;
    bool Return(std::string& output) override;
    bool IsAvailable(std::string& output) const override;

    // ==================== AFFICHAGE ====================

    void Display() const override;
};
