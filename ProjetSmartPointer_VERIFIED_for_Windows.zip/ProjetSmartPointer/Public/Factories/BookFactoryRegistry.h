
#pragma once

#include "Books/Book.h"
#include "Factories/FactoryRegistry.h"

// Registre specialise pour la creation des livres.
//
// Il herite du registre generique FactoryRegistry<Book>
// et enregistre automatiquement les trois fabriques
// concretes lors de sa construction.
class BookFactoryRegistry final : public FactoryRegistry<Book>
{
public:
    // Enregistre les fabriques des livres papier,
    // numeriques et audio.
    BookFactoryRegistry();
};
