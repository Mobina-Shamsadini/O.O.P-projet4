
#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Books/Book.h"
#include "Interfaces/IFactory.h"

// Fabrique concrete pour les livres numeriques.
//
// Transforme les champs CSV en un objet EBook.
// Retourne un unique_ptr<Book> afin de permettre
// le polymorphisme et le transfert de propriete.
class EBookFactory final : public IFactory<Book>
{
public:
    // Cree un livre numerique apres validation.
    //
    // Format attendu :
    // ebook,titre,auteur,url,taille
    //
    // Retourne nullptr si les donnees sont invalides.
    std::unique_ptr<Book> Create(
        const std::vector<std::string>& fields
    ) const override;
};
