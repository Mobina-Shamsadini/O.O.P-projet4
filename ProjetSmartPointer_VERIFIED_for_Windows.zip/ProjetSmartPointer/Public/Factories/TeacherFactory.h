
#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Interfaces/IFactory.h"
#include "Members/Member.h"

// Fabrique concrete pour les membres enseignants.
//
// Transforme une ligne CSV en un objet Teacher.
// Retourne un unique_ptr<Member> pour permettre
// le polymorphisme et le transfert de propriete.
class TeacherFactory final : public IFactory<Member>
{
public:
    // Cree un enseignant a partir des champs CSV.
    //
    // Format attendu :
    // teacher,nom,identifiant,departement,notifications
    //
    // Retourne nullptr si les donnees sont invalides.
    std::unique_ptr<Member> Create(
        const std::vector<std::string>& fields
    ) const override;
};
