
#pragma once

#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "Interfaces/IFactory.h"

// Registre generique de fabriques.
//
// T represente le type de base des objets crees
// (Book ou Member).
//
// Le registre est proprietaire de ses fabriques.
// Chaque fabrique est associee a une cle CSV.
template <typename T>
class FactoryRegistry
{
private:
    // Association entre une cle et sa fabrique.
    //
    // Exemple :
    // "physical" -> PhysicalBookFactory
    // "ebook"    -> EBookFactory
    // "audio"    -> AudioBookFactory
    //
    // unique_ptr assure la destruction automatique
    // des fabriques lors de la destruction du registre.
    std::map<std::string, std::unique_ptr<IFactory<T>>> factories_;

public:
    // ==================== CONSTRUCTEUR ====================

    FactoryRegistry() = default;

    // Destructeur : les unique_ptr liberent les fabriques.
    virtual ~FactoryRegistry() = default;

    // Le registre est proprietaire de ses fabriques.
    // La copie est interdite.
    FactoryRegistry(const FactoryRegistry&) = delete;
    FactoryRegistry& operator=(const FactoryRegistry&) = delete;

    // Le deplacement est autorise.
    FactoryRegistry(FactoryRegistry&&) = default;
    FactoryRegistry& operator=(FactoryRegistry&&) = default;

    // ==================== ENREGISTREMENT ====================

    // Enregistre une fabrique pour une cle CSV.
    //
    // Si la cle existe deja, l'enregistrement est refuse.
    // Le registre prend possession de la fabrique.
    bool RegisterFactory(
        const std::string& key,
        std::unique_ptr<IFactory<T>> factory)
    {
        if (key.empty() || factory == nullptr)
        {
            return false;
        }

        auto [it, inserted] = factories_.try_emplace(
            key, std::move(factory)
        );

        return inserted;
    }

    // ==================== CREATION ====================

    // Cree un objet selon le premier champ CSV.
    //
    // Retourne nullptr lorsque :
    // - la ligne est vide ;
    // - le type est inconnu ;
    // - la fabrique refuse les donnees ;
    // - une erreur survient durant la creation.
    //
    // CsvLoader se charge ensuite de journaliser
    // les lignes invalides avec [IGNORE].
    std::unique_ptr<T> Create(
        const std::vector<std::string>& fields) const
    {
        if (fields.empty())
        {
            return nullptr;
        }

        const auto it = factories_.find(fields[0]);

        if (it == factories_.end())
        {
            return nullptr;
        }

        try
        {
            return it->second->Create(fields);
        }
        catch (...)
        {
            // Une ligne CSV invalide ne doit pas
            // interrompre le chargement du fichier.
            return nullptr;
        }
    }
};
