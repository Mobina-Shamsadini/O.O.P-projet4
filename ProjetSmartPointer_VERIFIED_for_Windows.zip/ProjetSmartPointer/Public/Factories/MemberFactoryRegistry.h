
#pragma once

#include "Factories/FactoryRegistry.h"
#include "Members/Member.h"

// Registre specialise pour la creation des membres.
//
// Il herite du registre generique FactoryRegistry<Member>
// et enregistre automatiquement les fabriques
// des etudiants et des enseignants.
class MemberFactoryRegistry final : public FactoryRegistry<Member>
{
public:
    // Initialise le registre avec les fabriques
    // correspondant aux types du fichier members.csv.
    MemberFactoryRegistry();
};
