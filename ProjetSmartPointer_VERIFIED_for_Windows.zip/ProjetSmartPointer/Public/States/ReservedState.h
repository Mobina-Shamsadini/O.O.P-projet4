
#pragma once

#include <string>

#include "Interfaces/IBookState.h"

// Etat d'un livre reserve.
//
// Singleton : tous les livres reserves partagent
// la meme instance de ReservedState.
class ReservedState final : public IBookState
{
private:
    // Constructeur prive : empeche la creation directe.
    ReservedState() = default;

public:
    // Retourne l'instance unique de cet etat.
    static const ReservedState& GetInstance();

    // Copie interdite pour garantir le Singleton.
    ReservedState(const ReservedState&) = delete;
    ReservedState& operator=(const ReservedState&) = delete;

    // Transitions possibles depuis ReservedState.
    const IBookState* Checkout() const override;
    const IBookState* Return() const override;
    const IBookState* Reserve() const override;

    // Nom exact de l'etat utilise dans le journal.
    std::string GetLabel() const override;
};
//
// Created by Mobina Shamsadini on 2026-11-19.
//

#ifndef BIBLIOTHEQUE_RESERVEDSTATE_H
#define BIBLIOTHEQUE_RESERVEDSTATE_H

#endif //BIBLIOTHEQUE_RESERVEDSTATE_H
