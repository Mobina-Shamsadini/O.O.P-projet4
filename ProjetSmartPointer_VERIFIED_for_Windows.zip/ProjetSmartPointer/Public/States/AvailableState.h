
#pragma once

#include "Interfaces/IBookState.h"

// Etat d'un livre disponible.
//
// Singleton : tous les livres disponibles partagent
// la meme instance de AvailableState.
class AvailableState final : public IBookState
{
private:
    // Constructeur prive pour empecher la creation d'autres instances.
    AvailableState() = default;

public:
    // Acces a l'instance unique de cet etat.
    static const AvailableState& GetInstance();

    // Copie interdite pour respecter le Singleton.
    AvailableState(const AvailableState&) = delete;
    AvailableState& operator=(const AvailableState&) = delete;

    // Transitions possibles depuis AvailableState.
    const IBookState* Checkout() const override;
    const IBookState* Return() const override;
    const IBookState* Reserve() const override;

    // Nom de l'etat utilise dans le journal.
    std::string GetLabel() const override;
};
//
// Created by Mobina Shamsadini on 2026-11-19.
//

#ifndef BIBLIOTHEQUE_AVAILABLESTATE_H
#define BIBLIOTHEQUE_AVAILABLESTATE_H

#endif //BIBLIOTHEQUE_AVAILABLESTATE_H
