
#pragma once

#include <string>

#include "Interfaces/IBookState.h"

// Etat d'un livre deja emprunte.
//
// Singleton : tous les livres dans cet etat partagent
// la meme instance de CheckedOutState.
class CheckedOutState final : public IBookState
{
private:
    // Constructeur prive : empeche la creation directe.
    CheckedOutState() = default;

public:
    // Retourne l'instance unique de cet etat.
    static const CheckedOutState& GetInstance();

    // Copie interdite pour garantir le Singleton.
    CheckedOutState(const CheckedOutState&) = delete;
    CheckedOutState& operator=(const CheckedOutState&) = delete;

    // Transitions possibles depuis CheckedOutState.
    const IBookState* Checkout() const override;
    const IBookState* Return() const override;
    const IBookState* Reserve() const override;

    // Nom exact de l'etat pour le journal.
    std::string GetLabel() const override;
};
//
// Created by Mobina Shamsadini on 2026-11-19.
//

#ifndef BIBLIOTHEQUE_CHECKEDOUTSTATE_H
#define BIBLIOTHEQUE_CHECKEDOUTSTATE_H

#endif //BIBLIOTHEQUE_CHECKEDOUTSTATE_H
