
#pragma once

#include <fstream>
#include <string>

// Singleton : un seul journal partage par tout le programme.
class LibraryLogger
{
private:
    // Fichier dans lequel les evenements sont enregistres.
    std::ofstream file_;

    // Numero de la prochaine ligne du journal.
    int nextNumber_ = 1;

    // Constructeur prive : impossible de creer un logger directement.
    LibraryLogger();

public:
    // Une seule instance est accessible dans tout le programme.
    static LibraryLogger& GetInstance();

    // Enregistre un evenement avec son numero.
    void Log(const std::string& message);

    // Copie interdite pour garantir une seule instance.
    LibraryLogger(const LibraryLogger&) = delete;
    LibraryLogger& operator=(const LibraryLogger&) = delete;

    // Deplacement interdit egalement.
    LibraryLogger(LibraryLogger&&) = delete;
    LibraryLogger& operator=(LibraryLogger&&) = delete;
};
