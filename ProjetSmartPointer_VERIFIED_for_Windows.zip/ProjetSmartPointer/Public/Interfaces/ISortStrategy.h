
#pragma once

#include <string>

class Book;

// Interface du patron Strategy.
//
// Chaque strategie definit un critere de comparaison
// pour trier les livres du catalogue.
//
// Library utilise la strategie sans en etre proprietaire.
class ISortStrategy
{
public:
    // Destructeur virtuel pour permettre le polymorphisme.
    virtual ~ISortStrategy() = default;

    // Compare deux livres selon le critere choisi.
    //
    // Retourne true si a doit preceder b.
    // Cette methode est utilisee pour le tri.
    virtual bool Compare(
        const Book& a,
        const Book& b
    ) const = 0;

    // Retourne le nom de la strategie.
    //
    // Valeurs attendues :
    // "titre", "auteur" ou "etat".
    virtual std::string GetName() const = 0;

    // Effectue une comparaison avec un message explicatif.
    //
    // Cette methode est utilisee par le programme principal.
    // Elle reutilise Compare() pour respecter
    // le comportement de chaque strategie concrete.
    virtual bool Before(
        const Book& a,
        const Book& b,
        std::string& output
    ) const
    {
        const bool result = Compare(a, b);

        output = "Comparaison par " + GetName() +
                 (result
                     ? " : le premier livre precede le second"
                     : " : le premier livre ne precede pas le second");

        return result;
    }
};
