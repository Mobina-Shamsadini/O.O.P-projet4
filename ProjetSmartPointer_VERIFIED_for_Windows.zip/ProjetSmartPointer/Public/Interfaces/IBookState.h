
#pragma once

#include <string>

// Interface du patron State.
// Chaque etat decide si une operation est autorisee.
//
// Retourne un pointeur vers le prochain etat si l'action est acceptee,
// ou nullptr si elle est refusee.
//
// Les etats ne modifient jamais directement les livres.
class IBookState
{
public:
    // Destructeur virtuel de l'interface.
    virtual ~IBookState() = default;

    // Etat suivant apres un emprunt.
    virtual const IBookState* Checkout() const = 0;

    // Etat suivant apres un retour.
    virtual const IBookState* Return() const = 0;

    // Etat suivant apres une reservation.
    virtual const IBookState* Reserve() const = 0;

    // Nom exact de l'etat, utilise notamment dans le journal.
    virtual std::string GetLabel() const = 0;
};
//
// Created by Mobina Shamsadini on 2026-11-19.
//

#ifndef BIBLIOTHEQUE_IBOOKSTATE_H
#define BIBLIOTHEQUE_IBOOKSTATE_H

#endif //BIBLIOTHEQUE_IBOOKSTATE_H
