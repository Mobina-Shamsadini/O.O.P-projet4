
#pragma once

#include <string>

#include "Interfaces/ISortStrategy.h"

// Strategie concrete de tri des livres par etat.
//
// Compare les noms des etats dans l'ordre
// lexicographique croissant.
//
// La strategie ne possede aucun livre.
class SortByState final : public ISortStrategy
{
public:
    // Retourne true si l'etat de a precede
    // celui de b dans l'ordre lexicographique.
    bool Compare(
        const Book& a,
        const Book& b
    ) const override;

    // Retourne le nom du critere de tri.
    std::string GetName() const override;
};
