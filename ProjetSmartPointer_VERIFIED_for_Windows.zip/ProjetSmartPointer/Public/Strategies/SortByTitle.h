
#pragma once

#include <string>

#include "Interfaces/ISortStrategy.h"

// Strategie concrete de tri des livres par titre.
//
// Compare les titres dans l'ordre alphabetique croissant.
// La strategie ne possede aucun livre.
class SortByTitle final : public ISortStrategy
{
public:
    // Retourne true si le titre de a precede
    // celui de b dans l'ordre alphabetique.
    bool Compare(
        const Book& a,
        const Book& b
    ) const override;

    // Retourne le nom du critere de tri.
    std::string GetName() const override;
};
