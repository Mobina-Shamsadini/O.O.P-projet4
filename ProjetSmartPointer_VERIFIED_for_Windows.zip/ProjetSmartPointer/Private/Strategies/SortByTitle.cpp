
#include "Strategies/SortByTitle.h"

#include "Books/Book.h"

#include <string>

// ==================== COMPARAISON ====================

// Compare deux livres selon leur titre.
//
// La comparaison est croissante et respecte
// l'ordre lexicographique des chaines C++.
bool SortByTitle::Compare(
    const Book& a,
    const Book& b
) const
{
    return a.GetTitle() < b.GetTitle();
}

// ==================== NOM DE LA STRATEGIE ====================

// Retourne le nom utilise par Library
// pour identifier cette strategie de tri.
std::string SortByTitle::GetName() const
{
    return "titre";
}
