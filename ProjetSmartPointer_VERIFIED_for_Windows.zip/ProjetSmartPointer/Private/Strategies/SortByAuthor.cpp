
#include "Strategies/SortByAuthor.h"

#include "Books/Book.h"

#include <string>

// ==================== COMPARAISON ====================

// Compare deux livres selon le nom de leur auteur.
//
// Le tri est croissant et utilise la comparaison
// lexicographique des chaines C++.
bool SortByAuthor::Compare(
    const Book& a,
    const Book& b
) const
{
    return a.GetAuthor() < b.GetAuthor();
}

// ==================== NOM DE LA STRATEGIE ====================

// Retourne le nom utilise par Library
// pour identifier le critere de tri.
std::string SortByAuthor::GetName() const
{
    return "auteur";
}
