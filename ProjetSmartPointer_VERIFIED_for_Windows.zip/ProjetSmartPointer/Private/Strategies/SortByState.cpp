
#include "Strategies/SortByState.h"

#include "Books/Book.h"

#include <string>

// ==================== COMPARAISON ====================

// Les livres endommages sont places en premier.
// Les autres etats sont compares par leur nom.
//
// Le tri stable de Catalog conserve l'ordre
// des livres qui ont le meme etat.
bool SortByState::Compare(
    const Book& a,
    const Book& b
) const
{
    const std::string stateA = a.GetStateLabel();
    const std::string stateB = b.GetStateLabel();

    // Un livre endommage precede un livre non endommage.
    if (stateA == "DamagedState" &&
        stateB != "DamagedState")
    {
        return true;
    }

    if (stateA != "DamagedState" &&
        stateB == "DamagedState")
    {
        return false;
    }

    // Pour les autres cas, comparaison lexicographique.
    return stateA < stateB;
}

// ==================== NOM DE LA STRATEGIE ====================

std::string SortByState::GetName() const
{
    return "etat";
}
