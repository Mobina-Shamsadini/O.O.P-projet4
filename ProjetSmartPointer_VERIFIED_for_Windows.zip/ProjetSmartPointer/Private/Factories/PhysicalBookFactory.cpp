
#include "Factories/PhysicalBookFactory.h"

#include "Books/PhysicalBook.h"

#include <memory>
#include <string>
#include <vector>

// ==================== CREATION D'UN LIVRE PAPIER ====================

// Construit un PhysicalBook a partir des champs CSV.
//
// Format :
// physical,titre,auteur,rayon,etat
//
// Etats acceptes :
// "bon"       : livre disponible
// "endommage" : livre endommage
std::unique_ptr<Book> PhysicalBookFactory::Create(
    const std::vector<std::string>& fields) const
{
    // Verifie le nombre exact de champs.
    if (fields.size() != 5)
    {
        return nullptr;
    }

    // Verifie que la ligne correspond a cette fabrique.
    if (fields[0] != "physical")
    {
        return nullptr;
    }

    const std::string& title = fields[1];
    const std::string& author = fields[2];
    const std::string& shelf = fields[3];
    const std::string& condition = fields[4];

    // Les informations obligatoires ne peuvent pas
    // etre vides.
    if (title.empty() ||
        author.empty() ||
        shelf.empty())
    {
        return nullptr;
    }

    // Accepte uniquement les deux etats definis
    // dans le format CSV.
    if (condition != "bon" &&
        condition != "endommage")
    {
        return nullptr;
    }

    const bool damaged = (condition == "endommage");

    // Le type concret est cree ici.
    // La propriete est transferee au code appelant
    // par le unique_ptr<Book> retourne.
    return std::make_unique<PhysicalBook>(
        title,
        author,
        shelf,
        damaged
    );
}
