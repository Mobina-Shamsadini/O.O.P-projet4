
#include "Factories/StudentFactory.h"

#include "Members/Student.h"

#include <charconv>
#include <memory>
#include <string>
#include <system_error>
#include <vector>

// ==================== CREATION D'UN ETUDIANT ====================

// Construit un Student a partir des champs CSV.
//
// Format :
// student,nom,identifiant,programme,notifications
//
// L'identifiant doit etre un entier strictement positif.
// Les notifications acceptent uniquement "oui" ou "non".
std::unique_ptr<Member> StudentFactory::Create(
    const std::vector<std::string>& fields) const
{
    // Verifie le nombre exact de champs.
    if (fields.size() != 5)
    {
        return nullptr;
    }

    // Verifie le type de membre.
    if (fields[0] != "student")
    {
        return nullptr;
    }

    const std::string& name = fields[1];
    const std::string& idText = fields[2];
    const std::string& program = fields[3];
    const std::string& notificationsText = fields[4];

    // Verifie les champs obligatoires.
    if (name.empty() ||
        idText.empty() ||
        program.empty())
    {
        return nullptr;
    }

    // Convertit l'identifiant en entier.
    int memberId = 0;

    const char* begin = idText.data();
    const char* end = begin + idText.size();

    const auto [ptr, error] =
        std::from_chars(begin, end, memberId);

    // Refuse les identifiants invalides.
    if (error != std::errc{} ||
        ptr != end ||
        memberId <= 0)
    {
        return nullptr;
    }

    // Valide le choix des notifications.
    if (notificationsText != "oui" &&
        notificationsText != "non")
    {
        return nullptr;
    }

    const bool wantsNotifications =
        (notificationsText == "oui");

    // Cree l'etudiant avec le constructeur defini
    // dans Members/Student.h.
    return std::make_unique<Student>(
        name,
        memberId,
        program,
        wantsNotifications
    );
}
