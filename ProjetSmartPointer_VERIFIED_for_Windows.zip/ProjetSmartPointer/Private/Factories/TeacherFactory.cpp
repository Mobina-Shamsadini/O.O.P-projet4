
#include "Factories/TeacherFactory.h"

#include "Members/Teacher.h"

#include <charconv>
#include <memory>
#include <string>
#include <system_error>
#include <vector>

// ==================== CREATION D'UN ENSEIGNANT ====================

// Construit un Teacher a partir des champs CSV.
//
// Format :
// teacher,nom,identifiant,departement,notifications
//
// L'identifiant doit etre un entier strictement positif.
// Les notifications acceptent uniquement "oui" ou "non".
std::unique_ptr<Member> TeacherFactory::Create(
    const std::vector<std::string>& fields) const
{
    // Verifie le nombre exact de champs.
    if (fields.size() != 5)
    {
        return nullptr;
    }

    // Verifie que la ligne correspond a cette fabrique.
    if (fields[0] != "teacher")
    {
        return nullptr;
    }

    const std::string& name = fields[1];
    const std::string& idText = fields[2];
    const std::string& department = fields[3];
    const std::string& notificationsText = fields[4];

    // Verifie les champs obligatoires.
    if (name.empty() ||
        idText.empty() ||
        department.empty())
    {
        return nullptr;
    }

    // Convertit l'identifiant en entier.
    int memberId = 0;

    const char* begin = idText.data();
    const char* end = begin + idText.size();

    const auto [ptr, error] =
        std::from_chars(begin, end, memberId);

    // Refuse les identifiants non numeriques,
    // incomplets, nuls ou negatifs.
    if (error != std::errc{} ||
        ptr != end ||
        memberId <= 0)
    {
        return nullptr;
    }

    // Accepte uniquement les valeurs oui et non.
    if (notificationsText != "oui" &&
        notificationsText != "non")
    {
        return nullptr;
    }

    const bool wantsNotifications =
        (notificationsText == "oui");

    // Cree un objet Teacher avec le constructeur
    // defini par la classe Members/Teacher.
    return std::make_unique<Teacher>(
        name,
        memberId,
        department,
        wantsNotifications
    );
}
