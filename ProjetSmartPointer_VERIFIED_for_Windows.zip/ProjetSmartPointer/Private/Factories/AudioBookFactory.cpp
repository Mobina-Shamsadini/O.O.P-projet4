
#include "Factories/AudioBookFactory.h"

#include "Books/AudioBook.h"

#include <charconv>
#include <memory>
#include <string>
#include <system_error>
#include <vector>

// ==================== CONVERSION DES ENTIERS ====================

// Convertit une chaine en entier strictement positif.
// Retourne false si la chaine est vide, incorrecte,
// trop grande ou contient des caracteres supplementaires.
namespace
{
    bool ParsePositiveInt(const std::string& text, int& value)
    {
        if (text.empty())
        {
            return false;
        }

        int result = 0;

        const char* begin = text.data();
        const char* end = begin + text.size();

        const auto [ptr, error] =
            std::from_chars(begin, end, result);

        if (error != std::errc{} || ptr != end)
        {
            return false;
        }

        if (result <= 0)
        {
            return false;
        }

        value = result;
        return true;
    }
}

// ==================== CREATION D'UN LIVRE AUDIO ====================

// Construit un AudioBook a partir des champs CSV.
//
// Format :
// audio,titre,auteur,narrateur,duree,licences
std::unique_ptr<Book> AudioBookFactory::Create(
    const std::vector<std::string>& fields) const
{
    // Verifie le nombre exact de champs.
    if (fields.size() != 6)
    {
        return nullptr;
    }

    // Verifie que la ligne correspond a cette fabrique.
    if (fields[0] != "audio")
    {
        return nullptr;
    }

    const std::string& title = fields[1];
    const std::string& author = fields[2];
    const std::string& narrator = fields[3];
    const std::string& durationText = fields[4];
    const std::string& licensesText = fields[5];

    // Les informations textuelles obligatoires
    // ne peuvent pas etre vides.
    if (title.empty() ||
        author.empty() ||
        narrator.empty())
    {
        return nullptr;
    }

    int durationMinutes = 0;
    int maxListeners = 0;

    // Valide la duree du livre audio.
    if (!ParsePositiveInt(durationText, durationMinutes))
    {
        return nullptr;
    }

    // Valide le nombre de licences simultanees.
    if (!ParsePositiveInt(licensesText, maxListeners))
    {
        return nullptr;
    }

    // Cree le livre audio.
    // Le unique_ptr retourne transfere la propriete
    // de l'objet au code appelant.
    return std::make_unique<AudioBook>(
        title,
        author,
        narrator,
        durationMinutes,
        maxListeners
    );
}
