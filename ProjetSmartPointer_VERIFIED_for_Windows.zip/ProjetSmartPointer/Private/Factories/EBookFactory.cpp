
#include "Factories/EBookFactory.h"

#include "Books/EBook.h"

#include <charconv>
#include <memory>
#include <string>
#include <system_error>
#include <vector>

// ==================== CREATION D'UN LIVRE NUMERIQUE ====================

// Construit un EBook a partir des champs CSV.
//
// Format :
// ebook,titre,auteur,url,taille
//
// La taille doit etre un entier strictement positif.
std::unique_ptr<Book> EBookFactory::Create(
    const std::vector<std::string>& fields) const
{
    // Verifie le nombre exact de champs.
    if (fields.size() != 5)
    {
        return nullptr;
    }

    // Verifie que la ligne correspond a cette fabrique.
    if (fields[0] != "ebook")
    {
        return nullptr;
    }

    const std::string& title = fields[1];
    const std::string& author = fields[2];
    const std::string& url = fields[3];
    const std::string& sizeText = fields[4];

    // Les champs obligatoires ne peuvent pas etre vides.
    if (title.empty() ||
        author.empty() ||
        url.empty() ||
        sizeText.empty())
    {
        return nullptr;
    }

    // Convertit la taille en entier.
    // from_chars permet de refuser les valeurs
    // incorrectes sans lancer d'exception.
    int fileSizeMb = 0;

    const char* begin = sizeText.data();
    const char* end = begin + sizeText.size();

    const auto [ptr, error] =
        std::from_chars(begin, end, fileSizeMb);

    // Verifie que la conversion a reussi et que
    // tous les caracteres ont ete consommes.
    if (error != std::errc{} || ptr != end)
    {
        return nullptr;
    }

    // La taille du fichier doit etre positive.
    if (fileSizeMb <= 0)
    {
        return nullptr;
    }

    // Cree le livre numerique.
    // Le registre ou le chargeur recevra la propriete
    // de l'objet par le unique_ptr retourne.
    return std::make_unique<EBook>(
        title,
        author,
        url,
        fileSizeMb
    );
}
