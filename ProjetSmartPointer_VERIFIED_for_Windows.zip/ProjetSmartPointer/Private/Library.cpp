
#include "Library.h"

#include <algorithm>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "Books/Book.h"
#include "Interfaces/IBookObserver.h"
#include "Interfaces/ISortStrategy.h"
#include "Members/Member.h"

// ==================== AJOUT AUX CATALOGUES ====================

// Transfere la propriete du livre au catalogue.
void Library::AddBook(std::unique_ptr<Book> book)
{
    books_.Add(std::move(book));
}

// Transfere la propriete du membre au catalogue.
void Library::AddMember(std::unique_ptr<Member> member)
{
    members_.Add(std::move(member));
}

// ==================== RECHERCHE ====================

// Recherche un livre selon son titre.
// Le pointeur retourne ne transfere aucune propriete.
Book* Library::FindBook(const std::string& title) const
{
    return books_.FindIf(
        [&title](const Book& book)
        {
            return book.GetTitle() == title;
        }
    );
}

// Recherche un membre selon son nom.
// Le pointeur retourne ne transfere aucune propriete.
Member* Library::FindMember(const std::string& name) const
{
    return members_.FindIf(
        [&name](const Member& member)
        {
            return member.GetName() == name;
        }
    );
}

// ==================== STRATEGY ====================

// Trie les livres selon la strategie selectionnee.
//
// Sans strategie, aucun tri n'est effectue.
// Le catalogue utilise un tri par insertion stable.
void Library::SortBooks()
{
    if (sortStrategy_ == nullptr)
    {
        return;
    }

    books_.Sort(*sortStrategy_);
}

// ==================== AFFICHAGE ====================

// Affiche tous les livres du catalogue.
void Library::DisplayCatalog() const
{
    books_.DisplayAll();
}

// Affiche tous les membres du catalogue.
void Library::DisplayMembers() const
{
    members_.DisplayAll();
}

// ==================== OBSERVER ====================

// Inscrit un observateur sur la liste d'attente
// d'un livre.
//
// La meme personne ne peut pas etre inscrite
// plusieurs fois pour le meme livre.
void Library::Subscribe(
    const Book& book,
    IBookObserver& observer)
{
    auto& observers = waitLists_[&book];

    const auto it = std::find(
        observers.begin(),
        observers.end(),
        &observer
    );

    if (it == observers.end())
    {
        observers.push_back(&observer);
    }
}

// Retire un observateur de la liste d'attente.
//
// Aucun livre ou observateur n'est detruit ici.
void Library::Unsubscribe(
    const Book& book,
    const IBookObserver& observer)
{
    const auto it = waitLists_.find(&book);

    if (it == waitLists_.end())
    {
        return;
    }

    auto& observers = it->second;

    std::erase_if(
        observers,
        [&observer](IBookObserver* current)
        {
            return current == &observer;
        }
    );

    if (observers.empty())
    {
        waitLists_.erase(it);
    }
}

// Verifie si un observateur est inscrit
// sur la liste d'attente d'un livre.
bool Library::IsWaiting(
    const Book& book,
    const IBookObserver& observer,
    std::string& output) const
{
    const auto it = waitLists_.find(&book);

    if (it == waitLists_.end())
    {
        output = "aucune attente pour " + book.GetTitle();
        return false;
    }

    const auto& observers = it->second;

    const bool waiting = std::find(
        observers.begin(),
        observers.end(),
        &observer
    ) != observers.end();

    if (waiting)
    {
        output = "observateur en attente pour " +
                 book.GetTitle();
    }
    else
    {
        output = "observateur non inscrit pour " +
                 book.GetTitle();
    }

    return waiting;
}

// Informe tous les observateurs lorsqu'un livre
// redevient disponible.
//
// Chaque observateur est notifie une seule fois.
// La liste est retiree avant les notifications.
void Library::NotifyAvailable(const Book& book)
{
    const auto it = waitLists_.find(&book);

    if (it == waitLists_.end())
    {
        return;
    }

    std::vector<IBookObserver*> observers =
        std::move(it->second);

    waitLists_.erase(it);

    for (IBookObserver* observer : observers)
    {
        if (observer != nullptr)
        {
            observer->OnBookAvailable(book);
        }
    }
}

// ==================== EMPRUNT ====================

// Tente d'emprunter un livre pour un membre.
//
// Member verifie les doublons et les limites.
// Book verifie les regles propres a son type.
//
// Library gere les listes d'attente.
//
// La commande est responsable de journaliser
// [EMPRUNT] ou [REFUS].
bool Library::BorrowBook(
    Member& member,
    Book& book,
    std::string& output)
{
    if (member.Borrow(book, output))
    {
        return true;
    }

    // Inscrit le membre seulement si :
    // - le livre est deja emprunte ;
    // - le membre ne possede pas ce livre ;
    // - sa limite n'est pas atteinte ;
    // - il souhaite etre notifie.
    std::string detail;

    if (output == "CheckedOutState" &&
        !member.HasBorrowed(book, detail) &&
        member.CanBorrow() &&
        member.WantsNotifications())
    {
        Subscribe(book, member);
        output += ", en attente";
    }

    return false;
}

// ==================== RETOUR ====================

// Tente de rendre un livre emprunte.
//
// La commande journalise [RETOUR] avant
// d'appeler cette methode.
//
// Book journalise les transitions [ETAT].
// Library envoie ensuite les notifications.
bool Library::ReturnBook(
    Member& member,
    Book& book,
    std::string& output)
{
    // Verifie que le membre possede le livre.
    if (!member.HasBorrowed(book, output))
    {
        return false;
    }

    // Memorise la disponibilite avant le retour.
    std::string detail;

    const bool wasAvailable =
        book.IsAvailable(detail);

    // Effectue le retour.
    if (!member.Return(book, output))
    {
        return false;
    }

    // Verifie si le livre est maintenant disponible.
    const bool nowAvailable =
        book.IsAvailable(detail);

    // Notifie uniquement lorsqu'un livre
    // passe d'indisponible a disponible.
    if (!wasAvailable && nowAvailable)
    {
        NotifyAvailable(book);
    }

    return true;
}
