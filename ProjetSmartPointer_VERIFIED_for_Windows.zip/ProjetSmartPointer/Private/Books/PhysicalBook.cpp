
#include "Books/PhysicalBook.h"

#include "States/AvailableState.h"
#include "States/DamagedState.h"

#include <iostream>
#include <utility>

// ==================== CONSTRUCTEUR ====================

// Initialise le livre papier et son emplacement.
// L'etat initial depend de l'etat physique du livre.
PhysicalBook::PhysicalBook(std::string title,
                           std::string author,
                           std::string shelf,
                           bool damaged)
    : Book(std::move(title),
           std::move(author),
           damaged
               ? static_cast<const IBookState&>(
                     DamagedState::GetInstance())
               : static_cast<const IBookState&>(
                     AvailableState::GetInstance())),
      shelf_{std::move(shelf)}
{
}

// ==================== ACCESSEURS ====================

// Retourne l'emplacement du livre dans la bibliotheque.
const std::string& PhysicalBook::GetShelf() const
{
    return shelf_;
}

// Retourne le type utilise dans l'affichage et le journal.
std::string PhysicalBook::GetTypeLabel() const
{
    return "Papier";
}

// ==================== EMPRUNT ====================

// Un livre papier ne possede qu'un seul exemplaire.
// Le patron State refuse automatiquement un emprunt
// si le livre est deja emprunte ou endommage.
bool PhysicalBook::Checkout(std::string& output)
{
    return Book::Checkout(output);
}

// ==================== RETOUR ====================

// Un livre papier emprunte redevient disponible apres
// un retour valide. Un retour sans emprunt est refuse.
bool PhysicalBook::Return(std::string& output)
{
    return Book::Return(output);
}

// ==================== AFFICHAGE ====================

// Affichage propre aux livres papier.
void PhysicalBook::Display() const
{
    std::cout << "[Papier] "
              << GetTitle()
              << " par " << GetAuthor()
              << " | Rayon : " << shelf_
              << " | Etat : " << GetStateLabel()
              << '\n';
}
