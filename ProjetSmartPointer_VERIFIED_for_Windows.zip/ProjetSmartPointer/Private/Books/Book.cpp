
#include "Books/Book.h"

#include "LibraryLogger.h"

#include <string>
#include <utility>

// ==================== COMPTEUR STATIQUE ====================

// Nombre de livres actuellement vivants.
int Book::liveCount_ = 0;

// ==================== CONSTRUCTION / DESTRUCTION ====================

// Constructeur de la classe abstraite Book.
// Appele par les constructeurs des classes derivees.
Book::Book(std::string title,
           std::string author,
           const IBookState& initialState)
    : title_{std::move(title)},
      author_{std::move(author)},
      state_{&initialState}
{
    ++liveCount_;
}

// Destructeur virtuel.
// Les livres sont detruits automatiquement par leur proprietaire.
Book::~Book()
{
    --liveCount_;
}

// ==================== ACCESSEURS ====================

// Retourne le titre du livre.
const std::string& Book::GetTitle() const
{
    return title_;
}

// Retourne l'auteur du livre.
const std::string& Book::GetAuthor() const
{
    return author_;
}

// Retourne l'etat courant du livre.
const IBookState& Book::GetState() const
{
    return *state_;
}

// Retourne le nom de l'etat courant.
std::string Book::GetStateLabel() const
{
    return state_->GetLabel();
}

// Retourne le nombre de livres vivants.
int Book::GetLiveCount()
{
    return liveCount_;
}

// ==================== TRANSITION D'ETAT ====================

// Applique une transition seulement si elle est autorisee.
// Les objets State sont partages et ne sont jamais detruits ici.
bool Book::ApplyTransition(const IBookState* nextState)
{
    if (nextState == nullptr)
    {
        return false;
    }

    // Une transition vers le meme etat ne change rien.
    if (nextState == state_)
    {
        return true;
    }

    const std::string previousState = state_->GetLabel();
    const std::string newState = nextState->GetLabel();

    state_ = nextState;

    // Une seule methode journalise les transitions.
    LibraryLogger::GetInstance().Log(
        "[ETAT] " + title_ + " : " +
        previousState + " -> " + newState
    );

    return true;
}

// ==================== EMPRUNT ====================

// Demande a l'etat courant si l'emprunt est autorise.
// Les enfants peuvent redefinir cette methode pour gerer
// leurs regles particulieres.
bool Book::Checkout(std::string& output)
{
    const IBookState* nextState = state_->Checkout();

    if (nextState == nullptr)
    {
        output = "Emprunt refuse : " + title_ +
                 " (" + GetStateLabel() + ")";
        return false;
    }

    ApplyTransition(nextState);

    output = "Emprunt autorise : " + title_;
    return true;
}

// ==================== RETOUR ====================

// Demande a l'etat courant si le retour est autorise.
// Les livres numeriques et audio redefinissent cette
// methode pour gerer leurs prets ou licences simultanees.
bool Book::Return(std::string& output)
{
    const IBookState* nextState = state_->Return();

    if (nextState == nullptr)
    {
        output = "Retour refuse : " + title_ +
                 " (" + GetStateLabel() + ")";
        return false;
    }

    ApplyTransition(nextState);

    output = "Retour effectue : " + title_;
    return true;
}

// ==================== RESERVATION ====================

// Demande a l'etat courant si la reservation est autorisee.
bool Book::Reserve(std::string& output)
{
    const IBookState* nextState = state_->Reserve();

    if (nextState == nullptr)
    {
        output = "Reservation refusee : " + title_ +
                 " (" + GetStateLabel() + ")";
        return false;
    }

    ApplyTransition(nextState);

    output = "Reservation effectuee : " + title_;
    return true;
}

// ==================== DISPONIBILITE ====================

// Un livre est disponible pour un emprunt ordinaire
// uniquement lorsqu'il se trouve dans AvailableState.
//
// ReservedState autorise une transition vers CheckedOutState,
// mais le livre n'est pas disponible pour tous les membres.
bool Book::IsAvailable(std::string& output) const
{
    const bool available =
        GetStateLabel() == "AvailableState";

    if (available)
    {
        output = GetTitle() + " est disponible";
    }
    else
    {
        output = GetTitle() + " est indisponible (" +
                 GetStateLabel() + ")";
    }

    return available;
}
