
#include "Books/EBook.h"

#include "States/AvailableState.h"

#include <iostream>
#include <stdexcept>
#include <utility>

// ==================== CONSTRUCTEUR ====================

// Initialise le livre numerique dans AvailableState.
// Contrairement au livre papier, plusieurs emprunts
// peuvent etre actifs en meme temps.
EBook::EBook(std::string title,
             std::string author,
             std::string downloadUrl,
             int fileSizeMb)
    : Book(std::move(title),
           std::move(author),
           AvailableState::GetInstance()),
      downloadUrl_{std::move(downloadUrl)},
      fileSizeMb_{fileSizeMb}
{
    // La taille du fichier doit etre strictement positive.
    if (fileSizeMb_ <= 0)
    {
        throw std::invalid_argument(
            "La taille du livre numerique doit etre positive.");
    }
}

// ==================== ACCESSEURS ====================

// Retourne l'adresse de telechargement.
const std::string& EBook::GetDownloadUrl() const
{
    return downloadUrl_;
}

// Retourne la taille du fichier en Mo.
int EBook::GetFileSizeMb() const
{
    return fileSizeMb_;
}

// Retourne le nombre d'emprunts actifs.
int EBook::GetActiveLoans() const
{
    return activeLoans_;
}

// ==================== TYPE ====================

// Nom du type utilise par l'affichage et le chargement.
std::string EBook::GetTypeLabel() const
{
    return "Numerique";
}

// ==================== EMPRUNT ====================

// Un livre numerique accepte un nombre illimite de prets.
// Chaque emprunt augmente simplement le compteur.
//
// Le controle qu'un membre ne possede pas deja ce livre
// est effectue par Library, pas par EBook.
bool EBook::Checkout(std::string& output)
{
    if (GetStateLabel() != "AvailableState")
    {
        output = "Emprunt refuse : " + GetTitle() +
                 " (" + GetStateLabel() + ")";
        return false;
    }

    ++activeLoans_;

    output = "Emprunt autorise : " + GetTitle();
    return true;
}

// ==================== RETOUR ====================

// Un retour est autorise uniquement si un pret est actif.
// L'etat reste AvailableState tant qu'il s'agit d'un EBook.
bool EBook::Return(std::string& output)
{
    if (activeLoans_ == 0)
    {
        output = "Retour refuse : aucun emprunt en cours pour " +
                 GetTitle();
        return false;
    }

    --activeLoans_;

    output = "Retour effectue : " + GetTitle();
    return true;
}

// ==================== DISPONIBILITE ====================

// Un livre numerique est disponible pour plusieurs lecteurs.
// Aucune licence simultanee n'est imposee.
bool EBook::IsAvailable(std::string& output) const
{
    const bool available =
        GetStateLabel() == "AvailableState";

    if (available)
    {
        output = GetTitle() + " est disponible";
    }
    else
    {
        output = GetTitle() + " est indisponible (" +
                 GetStateLabel() + ")";
    }

    return available;
}

// ==================== AFFICHAGE ====================

// Affichage propre au livre numerique.
void EBook::Display() const
{
    std::cout << "[Numerique] "
              << GetTitle()
              << " par " << GetAuthor()
              << " | Taille : " << fileSizeMb_ << " Mo"
              << " | URL : " << downloadUrl_
              << " | Emprunts : " << activeLoans_
              << " | Etat : " << GetStateLabel()
              << '\n';
}
