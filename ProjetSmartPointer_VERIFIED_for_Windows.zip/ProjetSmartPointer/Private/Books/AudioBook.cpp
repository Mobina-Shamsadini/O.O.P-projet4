
#include "Books/AudioBook.h"

#include "States/AvailableState.h"
#include "States/CheckedOutState.h"
#include "States/ReservedState.h"

#include <iostream>
#include <stdexcept>
#include <utility>

// ==================== CONSTRUCTEUR ====================

// Initialise un livre audio dans AvailableState.
// Le nombre de licences et la duree doivent etre positifs.
AudioBook::AudioBook(std::string title,
                     std::string author,
                     std::string narrator,
                     int durationMinutes,
                     int maxListeners)
    : Book(std::move(title),
           std::move(author),
           AvailableState::GetInstance()),
      narrator_{std::move(narrator)},
      durationMinutes_{durationMinutes},
      maxListeners_{maxListeners}
{
    if (durationMinutes_ <= 0)
    {
        throw std::invalid_argument(
            "La duree du livre audio doit etre positive.");
    }

    if (maxListeners_ <= 0)
    {
        throw std::invalid_argument(
            "Le nombre de licences doit etre positif.");
    }
}

// ==================== ACCESSEURS ====================

// Retourne le nom du narrateur.
const std::string& AudioBook::GetNarrator() const
{
    return narrator_;
}

// Retourne la duree en minutes.
int AudioBook::GetDurationMinutes() const
{
    return durationMinutes_;
}

// Retourne le nombre maximal d'ecoutes simultanees.
int AudioBook::GetMaxListeners() const
{
    return maxListeners_;
}

// Retourne le nombre d'ecoutes en cours.
int AudioBook::GetActiveListeners() const
{
    return activeListeners_;
}

// ==================== TYPE ====================

std::string AudioBook::GetTypeLabel() const
{
    return "Audio";
}

// ==================== EMPRUNT ====================

// Autorise un emprunt s'il reste au moins une licence.
//
// Le livre passe a CheckedOutState lorsque la derniere
// licence devient occupee.
bool AudioBook::Checkout(std::string& output)
{
    if (activeListeners_ >= maxListeners_)
    {
        output = "Emprunt refuse : " + GetTitle() +
                 " (aucune licence disponible)";
        return false;
    }

    const IBookState& currentState = GetState();

    // CheckedOutState refuse les nouveaux emprunts.
    if (&currentState == &CheckedOutState::GetInstance())
    {
        output = "Emprunt refuse : " + GetTitle() +
                 " (CheckedOutState)";
        return false;
    }

    // Les etats autorises doivent permettre Checkout().
    const IBookState* nextState = currentState.Checkout();

    if (nextState == nullptr)
    {
        output = "Emprunt refuse : " + GetTitle() +
                 " (" + GetStateLabel() + ")";
        return false;
    }

    ++activeListeners_;

    // La derniere licence occupee provoque la transition.
    // Une reservation acceptee est egalement consommee
    // par un emprunt, selon le patron State.
    if (activeListeners_ == maxListeners_ ||
        &currentState == &ReservedState::GetInstance())
    {
        ApplyTransition(nextState);
    }

    output = "Emprunt autorise : " + GetTitle();
    return true;
}

// ==================== RETOUR ====================

// Libere une licence si un emprunt est en cours.
//
// Lorsque le livre etait complet, le premier retour
// le rend de nouveau disponible.
//
// Une reservation existante doit etre preservee.
bool AudioBook::Return(std::string& output)
{
    if (activeListeners_ == 0)
    {
        output = "Retour refuse : aucun emprunt en cours pour " +
                 GetTitle();
        return false;
    }

    const IBookState& currentState = GetState();

    if (&currentState == &CheckedOutState::GetInstance())
    {
        // Transition autorisee vers AvailableState.
        const IBookState* nextState = currentState.Return();

        if (nextState == nullptr)
        {
            output = "Retour refuse : " + GetTitle();
            return false;
        }

        --activeListeners_;
        ApplyTransition(nextState);
    }
    else if (&currentState == &AvailableState::GetInstance() ||
             &currentState == &ReservedState::GetInstance())
    {
        // Une licence est liberee sans changer l'etat.
        // En particulier, ReservedState reste reserve.
        --activeListeners_;
    }
    else
    {
        output = "Retour refuse : " + GetTitle() +
                 " (" + GetStateLabel() + ")";
        return false;
    }

    output = "Retour effectue : " + GetTitle();
    return true;
}

// ==================== DISPONIBILITE ====================

// Le livre audio est disponible s'il reste une licence
// et si son etat permet un nouvel emprunt ordinaire.
bool AudioBook::IsAvailable(std::string& output) const
{
    const bool available =
        activeListeners_ < maxListeners_ &&
        &GetState() == &AvailableState::GetInstance();

    if (available)
    {
        output = GetTitle() + " est disponible";
    }
    else
    {
        output = GetTitle() + " est indisponible (" +
                 GetStateLabel() + ")";
    }

    return available;
}

// ==================== AFFICHAGE ====================

// Affichage specifique au livre audio.
void AudioBook::Display() const
{
    std::cout << "[Audio] "
              << GetTitle()
              << " par " << GetAuthor()
              << " | Narrateur : " << narrator_
              << " | Duree : " << durationMinutes_ << " min"
              << " | Ecoutes : " << activeListeners_
              << "/" << maxListeners_
              << " | Etat : " << GetStateLabel()
              << '\n';
}
