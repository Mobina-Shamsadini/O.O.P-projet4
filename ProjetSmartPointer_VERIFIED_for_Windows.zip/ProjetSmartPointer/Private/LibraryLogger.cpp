
#include "LibraryLogger.h"

#include <iostream>
#include <string>

// ==================== CONSTRUCTEUR ====================

// Constructeur prive : ouvre le fichier journal.
// Le mode trunc permet de recommencer avec un fichier vide
// a chaque nouvelle execution du programme.
LibraryLogger::LibraryLogger()
    : file_{"library.log", std::ios::out | std::ios::trunc}
{
    if (!file_.is_open())
    {
        std::cerr << "Erreur : impossible d'ouvrir library.log\n";
    }
}

// ==================== SINGLETON ====================

// Retourne toujours la meme instance du journal.
// L'instance est creee uniquement lors du premier appel.
LibraryLogger& LibraryLogger::GetInstance()
{
    static LibraryLogger instance;
    return instance;
}

// ==================== JOURNALISATION ====================

// Ajoute le numero de ligne, puis enregistre l'evenement
// dans le fichier et dans la console.
void LibraryLogger::Log(const std::string& message)
{
    const std::string numberedMessage =
        "[" + std::to_string(nextNumber_) + "] " + message;

    if (file_.is_open())
    {
        file_ << numberedMessage << '\n';
        file_.flush();
    }

    std::cout << numberedMessage << '\n';

    ++nextNumber_;
}
//
// Created by Mobina Shamsadini on 2026-11-19.
//
