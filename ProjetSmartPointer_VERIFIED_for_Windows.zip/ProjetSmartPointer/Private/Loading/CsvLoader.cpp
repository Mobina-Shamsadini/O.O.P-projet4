#include "Loading/CsvLoader.h"

std::vector<std::string> CsvLoader::SplitCsv(const std::string &line) {
    std::vector<std::string> fields;
    std::string field;
    for (char character: line) {
        if (character == ',') {
            fields.push_back(field);   // fin d'un champ
            field.clear();
        } else {
            field += character;
        }
    }
    fields.push_back(field);           // dernier champ
    return fields;
}

bool CsvLoader::ToInt(const std::string &text, int &value) {
    if (text.empty() || text.size() > 9)       // 9 chiffres : pas de debordement
        return false;
    int result = 0;
    for (char digit: text) {
        if (digit < '0' || digit > '9')
            return false;
        result = result * 10 + (digit - '0');
    }
    if (result <= 0)
        return false;
    value = result;
    return true;
}
