#include "Strategies/SortByState.h"

#include "Books/Book.h"
#include "States/DamagedState.h"

namespace
{
    // Un seul DamagedState existe (Singleton) : son adresse l'identifie.
    bool IsDamaged(const Book& book)
    {
        return &book.GetState() == &DamagedState::GetInstance();
    }
} // namespace

// Vrai seulement si book est endommage et other ne l'est pas : deux livres
// endommages, ou deux livres en bon etat, ne changent pas d'ordre.
bool SortByState::Before(const Book& book, const Book& other, std::string& output) const
{
    const bool before = IsDamaged(book) && !IsDamaged(other);
    output = book.GetTitle() + " (" + book.GetStateLabel() + ")"
             + (before ? " passe avant " : " ne passe pas avant ") + other.GetTitle() + " ("
             + other.GetStateLabel() + ")";
    return before;
}
