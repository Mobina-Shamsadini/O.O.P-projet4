#include "Strategies/SortByAuthor.h"

#include "Books/Book.h"

bool SortByAuthor::Before(const Book& book, const Book& other, std::string& output) const
{
    const bool before = book.GetAuthor() < other.GetAuthor();
    output = book.GetTitle() + (before ? " passe avant " : " ne passe pas avant ")
             + other.GetTitle() + " (" + book.GetAuthor() + " / " + other.GetAuthor() + ")";
    return before;
}
