#include "Strategies/SortByTitle.h"

#include "Books/Book.h"

bool SortByTitle::Before(const Book& book, const Book& other, std::string& output) const
{
    const bool before = book.GetTitle() < other.GetTitle();
    output = book.GetTitle() + (before ? " passe avant " : " ne passe pas avant ")
             + other.GetTitle() + " (ordre des titres)";
    return before;
}
