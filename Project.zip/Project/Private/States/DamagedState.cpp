#include "States/DamagedState.h"

// ==================== SINGLETON ====================

// Retourne toujours la meme instance de DamagedState.
const DamagedState& DamagedState::GetInstance()
{
    static const DamagedState instance;
    return instance;
}

// ==================== TRANSITIONS ====================

// Un livre endommage ne peut pas etre emprunte.
const IBookState* DamagedState::Checkout() const
{
    return nullptr;
}

// Un livre endommage ne peut pas etre retourne
// par une operation normale de retour.
const IBookState* DamagedState::Return() const
{
    return nullptr;
}

// Un livre endommage ne peut pas etre reserve.
const IBookState* DamagedState::Reserve() const
{
    return nullptr;
}

// ==================== AFFICHAGE ====================

// Nom exact utilise pour les transitions dans le journal.
std::string DamagedState::GetLabel() const
{
    return "DamagedState";
}
