#include "States/AvailableState.h"

#include "States/CheckedOutState.h"
#include "States/ReservedState.h"

// ==================== SINGLETON ====================

// Retourne l'unique instance de AvailableState.
const AvailableState& AvailableState::GetInstance()
{
    static const AvailableState instance;
    return instance;
}

// ==================== TRANSITIONS ====================

// Un livre disponible peut etre emprunte.
const IBookState* AvailableState::Checkout() const
{
    return &CheckedOutState::GetInstance();
}

// Un livre disponible ne peut pas etre retourne
// puisqu'il n'est pas actuellement emprunte.
const IBookState* AvailableState::Return() const
{
    return nullptr;
}

// Un livre disponible peut etre reserve.
const IBookState* AvailableState::Reserve() const
{
    return &ReservedState::GetInstance();
}

// ==================== AFFICHAGE ====================

// Retourne le nom exact de la classe pour le journal.
std::string AvailableState::GetLabel() const
{
    return "AvailableState";
}
