#include "States/ReservedState.h"

#include "States/CheckedOutState.h"

// ==================== SINGLETON ====================

// Retourne toujours la meme instance de ReservedState.
const ReservedState& ReservedState::GetInstance()
{
    static const ReservedState instance;
    return instance;
}

// ==================== TRANSITIONS ====================

// Un livre reserve peut etre emprunte.
const IBookState* ReservedState::Checkout() const
{
    return &CheckedOutState::GetInstance();
}

// Un livre reserve ne peut pas etre retourne
// puisqu'il n'est pas encore emprunte.
const IBookState* ReservedState::Return() const
{
    return nullptr;
}

// Un livre deja reserve ne peut pas etre reserve une seconde fois.
const IBookState* ReservedState::Reserve() const
{
    return nullptr;
}

// ==================== AFFICHAGE ====================

// Retourne le nom exact utilise dans le journal.
std::string ReservedState::GetLabel() const
{
    return "ReservedState";
}
