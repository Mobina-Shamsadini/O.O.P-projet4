#include "States/CheckedOutState.h"

#include "States/AvailableState.h"

// ==================== SINGLETON ====================

// Retourne l'unique instance de CheckedOutState.
const CheckedOutState& CheckedOutState::GetInstance()
{
    static const CheckedOutState instance;
    return instance;
}

// ==================== TRANSITIONS ====================

// Un livre deja emprunte ne peut pas etre emprunte de nouveau.
// Les regles particulieres des livres numeriques et audio
// seront gerees dans leurs propres classes.
const IBookState* CheckedOutState::Checkout() const
{
    return nullptr;
}

// Un livre emprunte peut etre retourne et redevient disponible.
const IBookState* CheckedOutState::Return() const
{
    return &AvailableState::GetInstance();
}

// Un livre deja emprunte ne peut pas etre reserve directement.
// Les listes d'attente sont gerees par Library (Observer).
const IBookState* CheckedOutState::Reserve() const
{
    return nullptr;
}

// ==================== AFFICHAGE ====================

// Retourne le nom exact utilise dans le journal.
std::string CheckedOutState::GetLabel() const
{
    return "CheckedOutState";
}
