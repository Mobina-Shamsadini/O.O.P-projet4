#include "Books/AudioBook.h"

#include "Interfaces/IBookState.h"
#include "States/AvailableState.h"

#include <iostream>
#include <utility>

// ==================== CONSTRUCTEUR ====================

// La fabrique a deja validé la duree et les licences :
// aucune vérification ici.
AudioBook::AudioBook(std::string title, std::string author, std::string narrator,
                     int durationMinutes, int maxListeners)
    : Book(std::move(title), std::move(author), AvailableState::GetInstance()),
      narrator_{std::move(narrator)}, durationMinutes_{durationMinutes}, maxListeners_{maxListeners}
{
}

// ==================== TYPE ====================

std::string AudioBook::GetTypeLabel() const
{
    return "Audio";
}

// ==================== EMPRUNT ====================

// L'état decide si l'emprunt est permis (un titre sorti ou
// endommagé refuse). Le titre change d'etat seulement au
// depart de la derniere licence.
bool AudioBook::Checkout(std::string& output)
{
    const IBookState* nextState = GetState().Checkout();

    if (!Allows(nextState, "Emprunt refuse", output))
    {
        return false;
    }

    ++activeListeners_;

    if (activeListeners_ == maxListeners_)
    {
        return ApplyTransition(nextState, "Emprunt refuse", output);
    }

    output = GetTitle() + " : licence accordee (" + std::to_string(activeListeners_) + " sur "
             + std::to_string(maxListeners_) + ")";
    return true;
}

// ==================== RETOUR ====================

// Une licence qui revient rend le titre disponible seulement
// s'il était sorti : un titre reserve reste reserve.
bool AudioBook::Return(std::string& output)
{
    if (activeListeners_ == 0)
    {
        output = "Retour refuse : aucun emprunt en cours pour " + GetTitle();
        return false;
    }

    --activeListeners_;

    if (IsCheckedOut())
    {
        return ApplyTransition(GetState().Return(), "Retour refuse", output);
    }

    output = GetTitle() + " : licence rendue (" + std::to_string(activeListeners_) + " sur "
             + std::to_string(maxListeners_) + " en cours)";
    return true;
}

// ==================== AFFICHAGE ====================

void AudioBook::Display() const
{
    std::cout << "[Audio] " << GetTitle() << " par " << GetAuthor()
              << " | Narrateur : " << narrator_ << " | Duree : " << durationMinutes_ << " min"
              << " | Ecoutes : " << activeListeners_ << "/" << maxListeners_
              << " | Etat : " << GetStateLabel() << '\n';
}
