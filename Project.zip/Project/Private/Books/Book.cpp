#include "Books/Book.h"

#include "LibraryLogger.h"
#include "States/AvailableState.h"
#include "States/CheckedOutState.h"

#include <string>
#include <utility>

// ==================== COMPTEUR STATIQUE ====================

// Nombre de livres actuellement vivants.
int Book::liveCount_ = 0;

// ==================== CONSTRUCTION / DESTRUCTION ====================

// Constructeur de la classe abstraite Book.
// Appele par les constructeurs des classes derivees.
Book::Book(std::string title, std::string author, const IBookState& initialState)
    : title_{std::move(title)}, author_{std::move(author)}, state_{&initialState}
{
    ++liveCount_;
}

// Destructeur virtuel.
// Les livres sont detruits automatiquement par leur proprietaire.
Book::~Book()
{
    --liveCount_;
}

// ==================== ACCESSEURS ====================

const std::string& Book::GetTitle() const
{
    return title_;
}

const std::string& Book::GetAuthor() const
{
    return author_;
}

const IBookState& Book::GetState() const
{
    return *state_;
}

std::string Book::GetStateLabel() const
{
    return state_->GetLabel();
}

int Book::GetLiveCount()
{
    return liveCount_;
}

// ==================== TRANSITION D'ETAT ====================

bool Book::Allows(const IBookState* nextState, const std::string& refusal,
                  std::string& output) const
{
    if (nextState != nullptr)
    {
        return true;
    }

    output = refusal + " : " + title_ + " (" + GetStateLabel() + ")";
    return false;
}

// Une seule methode change l'etat et journalise la transition.
// Les objets State sont partages et ne sont jamais detruits ici.
bool Book::ApplyTransition(const IBookState* nextState, const std::string& refusal,
                           std::string& output)
{
    if (!Allows(nextState, refusal, output))
    {
        return false;
    }

    output = title_ + " : " + state_->GetLabel() + " -> " + nextState->GetLabel();
    LibraryLogger::GetInstance().Log("[ETAT] " + output);
    state_ = nextState;
    return true;
}

// ==================== OPERATIONS ====================

// Les trois colonnes du tableau des transitions :
// l'état courant decide, le livre applique.
bool Book::Checkout(std::string& output)
{
    return ApplyTransition(state_->Checkout(), "Emprunt refuse", output);
}

bool Book::Return(std::string& output)
{
    return ApplyTransition(state_->Return(), "Retour refuse", output);
}

bool Book::Reserve(std::string& output)
{
    return ApplyTransition(state_->Reserve(), "Reservation refusee", output);
}

// ==================== DISPONIBILITE ====================

// Un seul AvailableState existe (Singleton) : son adresse l'identifie.
// ReservedState accepte un emprunt au comptoir, mais le livre
// n'est pas disponible pour tous les membres.
bool Book::IsAvailable(std::string& output) const
{
    if (state_ != &AvailableState::GetInstance())
    {
        output = title_ + " est indisponible (" + GetStateLabel() + ")";
        return false;
    }

    output = title_ + " est disponible";
    return true;
}

bool Book::IsCheckedOut() const
{
    return state_ == &CheckedOutState::GetInstance();
}
