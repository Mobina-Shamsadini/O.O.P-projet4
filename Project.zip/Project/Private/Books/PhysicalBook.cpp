#include "Books/PhysicalBook.h"

#include "States/AvailableState.h"
#include "States/DamagedState.h"

#include <iostream>
#include <utility>

namespace
{
    // L'etat de depart depend de l'etat physique du livre.
    const IBookState& InitialState(bool damaged)
    {
        if (damaged)
        {
            return DamagedState::GetInstance();
        }
        return AvailableState::GetInstance();
    }
} // namespace

// ==================== CONSTRUCTEUR ====================

// L'etat de depart est choisi dans la liste d'initialisation :
// ce n'est pas une transition, rien n'est journalise.
PhysicalBook::PhysicalBook(std::string title, std::string author, std::string shelf, bool damaged)
    : Book(std::move(title), std::move(author), InitialState(damaged)), shelf_{std::move(shelf)}
{
}

// ==================== TYPE ====================

std::string PhysicalBook::GetTypeLabel() const
{
    return "Papier";
}

// ==================== AFFICHAGE ====================

void PhysicalBook::Display() const
{
    std::cout << "[Papier] " << GetTitle() << " par " << GetAuthor() << " | Rayon : " << shelf_
              << " | Etat : " << GetStateLabel() << '\n';
}
