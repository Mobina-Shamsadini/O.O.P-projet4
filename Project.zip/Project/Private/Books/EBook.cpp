#include "Books/EBook.h"

#include "Interfaces/IBookState.h"
#include "States/AvailableState.h"

#include <iostream>
#include <utility>

// ==================== CONSTRUCTEUR ====================

// La fabrique a deja valide la taille : aucune verification ici.
EBook::EBook(std::string title, std::string author, std::string downloadUrl, int fileSizeMb)
    : Book(std::move(title), std::move(author), AvailableState::GetInstance()),
      downloadUrl_{std::move(downloadUrl)}, fileSizeMb_{fileSizeMb}
{
}

// ==================== TYPE ====================

std::string EBook::GetTypeLabel() const
{
    return "Numerique";
}

// ==================== EMPRUNT ====================

// L'etat doit accepter l'emprunt, mais le livre ne change pas
// d'etat : une copie numerique de plus ne retire rien du rayon.
//
// Le controle qu'un membre ne possede pas deja ce livre
// est effectue par Member, pas par EBook.
bool EBook::Checkout(std::string& output)
{
    if (!Allows(GetState().Checkout(), "Emprunt refuse", output))
    {
        return false;
    }

    ++activeLoans_;
    output =
        GetTitle() + " : pret numerique accorde (" + std::to_string(activeLoans_) + " en cours)";
    return true;
}

// ==================== RETOUR ====================

// Disponible, l'etat refuserait tout retour : la regle propre
// au livre numerique est donc de compter ses prets.
bool EBook::Return(std::string& output)
{
    if (activeLoans_ == 0)
    {
        output = "Retour refuse : aucun emprunt en cours pour " + GetTitle();
        return false;
    }

    --activeLoans_;
    output =
        GetTitle() + " : pret numerique termine (" + std::to_string(activeLoans_) + " en cours)";
    return true;
}

// ==================== AFFICHAGE ====================

void EBook::Display() const
{
    std::cout << "[Numerique] " << GetTitle() << " par " << GetAuthor()
              << " | Taille : " << fileSizeMb_ << " Mo" << " | URL : " << downloadUrl_
              << " | Emprunts : " << activeLoans_ << " | Etat : " << GetStateLabel() << '\n';
}
