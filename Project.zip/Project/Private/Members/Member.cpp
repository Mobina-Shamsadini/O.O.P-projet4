#include "Members/Member.h"

#include <algorithm>
#include <iostream>
#include <string>

#include "Books/Book.h"
#include "LibraryLogger.h"

// ==================== COMPTEUR STATIQUE ====================

// Nombre de membres actuellement vivants.
int Member::liveCount_ = 0;

// ==================== CONSTRUCTEUR ====================

// Initialise les informations du membre.
//
// *this : le membre se donne lui-meme comme
// proprietaire de son panier.
Member::Member(const std::string& name, int memberId, const std::string& affiliation,
               bool wantsNotifications)
    : name_{name}, memberId_{memberId}, affiliation_{affiliation},
      wantsNotifications_{wantsNotifications}, cart_{*this}
{
    ++liveCount_;
}

// ==================== DESTRUCTEUR ====================

// Les ressources possedees sont detruites automatiquement.
Member::~Member()
{
    --liveCount_;
}

// ==================== VERIFICATION DES EMPRUNTS ====================

// Verifie si le membre peut emprunter un livre supplementaire.
bool Member::CanBorrow() const
{
    return static_cast<int>(borrowedBooks_.size()) < GetMaxBooks();
}

// Verifie si le membre possede deja un emprunt du livre.
//
// true  : livre deja emprunte.
// false : aucun emprunt correspondant.
bool Member::HasBorrowed(const Book& book, std::string& output) const
{
    if (std::find(borrowedBooks_.begin(), borrowedBooks_.end(), &book) == borrowedBooks_.end())
    {
        output = "aucun emprunt";
        return false;
    }

    output = "deja emprunte par ce membre";
    return true;
}

// ==================== EMPRUNT ====================

// Verifie les cas de refus avant de demander
// au livre d'éffectuer son changement d'etat.
bool Member::Borrow(Book& book, std::string& output)
{
    if (HasBorrowed(book, output))
    {
        return false;
    }

    if (!CanBorrow())
    {
        output = "limite atteinte";
        return false;
    }

    std::string detail;

    if (!book.Checkout(detail))
    {
        // Nom de methode harmonise avec Book.h.
        output = book.GetStateLabel();
        return false;
    }

    // Le membre conserve un pointeur non proprietaire
    // vers le livre appartenant à Library.
    borrowedBooks_.push_back(&book);

    output = name_ + " a " + std::to_string(borrowedBooks_.size()) + " livre(s) sur "
             + std::to_string(GetMaxBooks()) + " (" + detail + ")";

    return true;
}

// ==================== RETOUR ====================

// Vérifie que le livre appartient aux emprunts du membre,
// puis demande au livre d'éffectuer son retour.
bool Member::Return(Book& book, std::string& output)
{
    if (!HasBorrowed(book, output))
    {
        return false;
    }

    if (!book.Return(output))
    {
        return false;
    }

    // Supprime seulement le pointeur de la liste.
    // Le livre lui-meme reste la propriété de Library.
    std::erase(borrowedBooks_, &book);

    return true;
}

// ==================== OBSERVER ====================

// Recoit une notification lorsqu'un livre devient disponible.
void Member::OnBookAvailable(const Book& book)
{
    LibraryLogger::GetInstance().Log("[NOTIFICATION] " + name_ + " : " + book.GetTitle()
                                     + " disponible");
}

// ==================== AFFICHAGE ====================

// Affiche les informations du membre et les titres empruntés.
void Member::Display() const
{
    std::cout << "  [" << GetTypeLabel() << "] " << name_ << " #" << memberId_ << ", "
              << affiliation_ << ", avis " << (wantsNotifications_ ? "oui" : "non") << ", "
              << borrowedBooks_.size() << "/" << GetMaxBooks() << " livre(s)";

    for (const Book* book : borrowedBooks_)
    {
        std::cout << " | " << book->GetTitle();
    }

    std::cout << '\n';
}
