#include "Members/Student.h"

// ==================== CONSTRUCTEUR ====================

// Initialise un etudiant avec son nom, son identifiant,
// son programme et son choix de notifications.
Student::Student(const std::string& name, int memberId, const std::string& program,
                 bool wantsNotifications)
    : Member{name, memberId, program, wantsNotifications}
{
}
