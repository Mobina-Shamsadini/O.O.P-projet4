#include "Members/Teacher.h"

// ==================== CONSTRUCTEUR ====================

// Initialise un enseignant avec son nom, son identifiant,
// son departement et son choix de notifications.
Teacher::Teacher(const std::string& name, int memberId, const std::string& department,
                 bool wantsNotifications)
    : Member{name, memberId, department, wantsNotifications}
{
}
