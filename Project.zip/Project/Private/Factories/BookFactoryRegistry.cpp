#include "Factories/BookFactoryRegistry.h"

#include "Factories/PhysicalBookFactory.h"
#include "Factories/EBookFactory.h"
#include "Factories/AudioBookFactory.h"

#include <memory>

// ==================== CONSTRUCTEUR ====================

// Initialise le registre avec les trois fabriques.
//
// Les clés correspondent au premier champ
// de chaque ligne du fichier books.csv.
BookFactoryRegistry::BookFactoryRegistry()
{
    // Fabrique des livres papier.
    RegisterFactory("physical", std::make_unique<PhysicalBookFactory>());

    // Fabrique des livres numeriques.
    RegisterFactory("ebook", std::make_unique<EBookFactory>());

    // Fabrique des livres audio.
    RegisterFactory("audio", std::make_unique<AudioBookFactory>());
}
