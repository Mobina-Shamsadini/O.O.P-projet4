#include "Factories/AudioBookFactory.h"

#include "Books/AudioBook.h"
#include "Loading/CsvLoader.h"

// ==================== CREATION D'UN LIVRE AUDIO ====================

// Construit un AudioBook à partir des champs CSV.
//
// Format :
// audio, titre, auteur, narrateur, duree, licences
//
// CsvLoader:: ToInt refuse sans exception "longue", 0
// et les nombres négatifs : un livre sans licence n'existe pas.
std::unique_ptr<Book> AudioBookFactory::Create(const std::vector<std::string>& fields) const
{
    constexpr std::size_t FIELD_COUNT = 6;

    if (fields.size() != FIELD_COUNT)
    {
        return nullptr;
    }

    const std::string& title = fields[1];
    const std::string& author = fields[2];
    const std::string& narrator = fields[3];

    // Les informations textuelles obligatoires ne peuvent pas être vides.
    if (title.empty() || author.empty() || narrator.empty())
    {
        return nullptr;
    }

    int durationMinutes = 0;
    int maxListeners = 0;

    if (!CsvLoader::ToInt(fields[4], durationMinutes) || !CsvLoader::ToInt(fields[5], maxListeners))
    {
        return nullptr;
    }

    return std::make_unique<AudioBook>(title, author, narrator, durationMinutes, maxListeners);
}
