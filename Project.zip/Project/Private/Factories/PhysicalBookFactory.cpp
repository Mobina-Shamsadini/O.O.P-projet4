#include "Factories/PhysicalBookFactory.h"

#include "Books/PhysicalBook.h"

// ==================== CREATION D'UN LIVRE PAPIER ====================

// Construit un PhysicalBook a partir des champs CSV.
//
// Format :
// physical,titre,auteur,rayon,etat
//
// Etats acceptes :
// "bon"       : livre disponible
// "endommage" : livre endommage
std::unique_ptr<Book> PhysicalBookFactory::Create(const std::vector<std::string>& fields) const
{
    constexpr std::size_t FIELD_COUNT = 5;

    if (fields.size() != FIELD_COUNT)
    {
        return nullptr;
    }

    const std::string& title = fields[1];
    const std::string& author = fields[2];
    const std::string& shelf = fields[3];
    const std::string& condition = fields[4];

    // Les informations obligatoires ne peuvent pas être vides.
    if (title.empty() || author.empty() || shelf.empty())
    {
        return nullptr;
    }

    // Accepte uniquement les deux états définis dans le format CSV.
    if (condition != "bon" && condition != "endommage")
    {
        return nullptr;
    }

    // Le type concret est cree ici, et seulement ici.
    return std::make_unique<PhysicalBook>(title, author, shelf, condition == "endommage");
}
