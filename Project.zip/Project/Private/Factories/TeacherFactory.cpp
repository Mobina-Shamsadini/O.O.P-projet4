#include "Factories/TeacherFactory.h"

#include "Loading/CsvLoader.h"
#include "Members/Teacher.h"

// ==================== CREATION D'UN ENSEIGNANT ====================

// Construit un Teacher a partir des champs CSV.
//
// Format :
// teacher, nom, identifiant, departement, notifications
//
// Identifiant : entier strictement positif (CsvLoader::ToInt).
// Notifications : "oui" ou "non" seulement.
std::unique_ptr<Member> TeacherFactory::Create(const std::vector<std::string>& fields) const
{
    constexpr std::size_t FIELD_COUNT = 5;

    if (fields.size() != FIELD_COUNT)
    {
        return nullptr;
    }

    const std::string& name = fields[1];
    const std::string& department = fields[3];
    const std::string& notifications = fields[4];

    if (name.empty() || department.empty())
    {
        return nullptr;
    }

    int memberId = 0;

    if (!CsvLoader::ToInt(fields[2], memberId))
    {
        return nullptr;
    }

    if (notifications != "oui" && notifications != "non")
    {
        return nullptr;
    }

    return std::make_unique<Teacher>(name, memberId, department, notifications == "oui");
}
