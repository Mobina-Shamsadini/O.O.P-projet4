#include "Factories/EBookFactory.h"

#include "Books/EBook.h"
#include "Loading/CsvLoader.h"

// ==================== CREATION D'UN LIVRE NUMERIQUE ====================

// Construit un EBook a partir des champs CSV.
//
// Format :
// ebook,titre,auteur,url,taille
//
// CsvLoader::ToInt refuse sans exception une taille vide,
// non numerique, nulle, negative ou trop longue.
std::unique_ptr<Book> EBookFactory::Create(const std::vector<std::string>& fields) const
{
    constexpr std::size_t FIELD_COUNT = 5;

    if (fields.size() != FIELD_COUNT)
    {
        return nullptr;
    }

    const std::string& title = fields[1];
    const std::string& author = fields[2];
    const std::string& url = fields[3];

    // Les champs obligatoires ne peuvent pas être vides.
    if (title.empty() || author.empty() || url.empty())
    {
        return nullptr;
    }

    int fileSizeMb = 0;

    if (!CsvLoader::ToInt(fields[4], fileSizeMb))
    {
        return nullptr;
    }

    return std::make_unique<EBook>(title, author, url, fileSizeMb);
}
