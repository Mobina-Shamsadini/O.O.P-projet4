#include "Factories/MemberFactoryRegistry.h"

#include "Factories/StudentFactory.h"
#include "Factories/TeacherFactory.h"

#include <memory>

// ==================== CONSTRUCTEUR ====================

// Enregistre automatiquement les fabriques des membres.
//
// Chaque clé correspond au premier champ
// d'une ligne du fichier members.csv.
MemberFactoryRegistry::MemberFactoryRegistry()
{
    // Fabrique des membres etudiants.
    RegisterFactory("student", std::make_unique<StudentFactory>());

    // Fabrique des membres enseignants.
    RegisterFactory("teacher", std::make_unique<TeacherFactory>());
}
