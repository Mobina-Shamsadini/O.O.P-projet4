#include "Factories/StudentFactory.h"

#include "Loading/CsvLoader.h"
#include "Members/Student.h"

// ==================== CREATION D'UN ETUDIANT ====================

// Construit un Student à partir des champs CSV.
//
// Format :
// student, nom, identifiant, programme, notifications
//
// Identifiant : entier strictement positif (CsvLoader::ToInt).
// Notifications : "oui" ou "non" seulement.
std::unique_ptr<Member> StudentFactory::Create(const std::vector<std::string>& fields) const
{
    constexpr std::size_t FIELD_COUNT = 5;

    if (fields.size() != FIELD_COUNT)
    {
        return nullptr;
    }

    const std::string& name = fields[1];
    const std::string& program = fields[3];
    const std::string& notifications = fields[4];

    if (name.empty() || program.empty())
    {
        return nullptr;
    }

    int memberId = 0;

    if (!CsvLoader::ToInt(fields[2], memberId))
    {
        return nullptr;
    }

    if (notifications != "oui" && notifications != "non")
    {
        return nullptr;
    }

    return std::make_unique<Student>(name, memberId, program, notifications == "oui");
}
