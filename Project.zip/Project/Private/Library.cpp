#include "Library.h"

#include <algorithm>
#include <iostream>
#include <utility>

#include "Books/Book.h"
#include "Interfaces/ISortStrategy.h"
#include "Members/Member.h"

void Library::AddBook(std::unique_ptr<Book> book)
{
    books_.Add(std::move(book));
}

void Library::AddMember(std::unique_ptr<Member> member)
{
    members_.Add(std::move(member));
}

Book* Library::FindBook(const std::string& title) const
{
    return books_.FindIf([&title](const Book& book) { return book.GetTitle() == title; });
}

Member* Library::FindMember(const std::string& name) const
{
    return members_.FindIf([&name](const Member& member) { return member.GetName() == name; });
}

// Sans strategie choisie, l'ordre est conserve.
void Library::SortBooks()
{
    if (sortStrategy_ != nullptr)
    {
        books_.Sort(*sortStrategy_);
    }
}

void Library::DisplayCatalog() const
{
    std::cout << "--- Catalogue : " << books_.Count() << " livre(s) ---\n";
    books_.DisplayAll();
}

void Library::DisplayMembers() const
{
    std::cout << "--- Membres : " << members_.Count() << " membre(s) ---\n";
    members_.DisplayAll();
}

// Un refus inscrit le membre, mais seulement si l'attente a un sens :
// le livre reviendra, le membre ne l'a pas deja, il pourra l'emprunter et
// il veut etre prevenu. Jamais deux fois sur la meme liste.
bool Library::BorrowBook(Member& member, Book& book, std::string& output)
{
    if (member.Borrow(book, output))
    {
        return true;
    }
    std::string detail;
    const bool worthWaiting = book.IsCheckedOut() && !member.HasBorrowed(book, detail)
                              && member.CanBorrow() && member.WantsNotifications();
    if (worthWaiting && !IsWaiting(book, member, detail))
    {
        Subscribe(book, member);
    }
    if (IsWaiting(book, member, detail))
    {
        output += ", en attente";
    }
    return false;
}

// Un retour previent la liste d'attente, si le livre est vraiment redevenu
// disponible (un livre audio reserve ne l'est pas).
bool Library::ReturnBook(Member& member, Book& book, std::string& output)
{
    if (!member.Return(book, output))
    {
        return false;
    }
    std::string detail;
    if (book.IsAvailable(detail))
    {
        NotifyAvailable(book);
    }
    return true;
}

void Library::Subscribe(const Book& book, IBookObserver& observer)
{
    waitLists_[&book].push_back(&observer);
}

void Library::Unsubscribe(const Book& book, const IBookObserver& observer)
{
    const auto found = waitLists_.find(&book);
    if (found == waitLists_.end())
    {
        return; // personne n'attend ce livre : rien a faire
    }
    std::erase(found->second, &observer);
    if (found->second.empty())
    {
        waitLists_.erase(found);
    }
}

bool Library::IsWaiting(const Book& book, const IBookObserver& observer, std::string& output) const
{
    const auto found = waitLists_.find(&book); // find : [] insererait une liste vide
    if (found == waitLists_.end())
    {
        output = "personne n'attend " + book.GetTitle();
        return false;
    }
    const std::vector<IBookObserver*>& waiting = found->second;
    const auto position = std::find(waiting.begin(), waiting.end(), &observer);
    if (position == waiting.end())
    {
        output = "absent de la liste d'attente de " + book.GetTitle();
        return false;
    }
    output = "sur la liste d'attente de " + book.GetTitle() + " (position "
             + std::to_string(position - waiting.begin() + 1) + " sur "
             + std::to_string(waiting.size()) + ")";
    return true;
}

void Library::NotifyAvailable(const Book& book)
{
    const auto found = waitLists_.find(&book);
    if (found == waitLists_.end())
    {
        return;
    }
    // Copie de la liste, puis effacement AVANT de notifier : chaque abonne
    // n'est prevenu qu'une fois, et peut se réinscrire pendant sa
    // notification sans perturber la boucle.
    const std::vector<IBookObserver*> waiting = found->second;
    waitLists_.erase(found);
    for (IBookObserver* observer : waiting)
    {
        observer->OnBookAvailable(book);
    }
}
