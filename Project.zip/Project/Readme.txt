                                    Membres du groupe 



Nikiéma Wendkouni Aïda         NIKW09580500

Shamsadini Motlagh Mobina      SHAM13520600