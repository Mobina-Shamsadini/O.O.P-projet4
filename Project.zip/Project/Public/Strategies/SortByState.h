#pragma once

#include "Interfaces/ISortStrategy.h"

// Les livres endommagés d'abord ; les autres gardent leur ordre (tri stable).
class SortByState : public ISortStrategy
{
public:
    bool Before(const Book& book, const Book& other, std::string& output) const override;
    std::string GetName() const override
    {
        return "etat";
    }
};

