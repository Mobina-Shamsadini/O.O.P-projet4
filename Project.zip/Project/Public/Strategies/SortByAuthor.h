#pragma once

#include "Interfaces/ISortStrategy.h"

// Ordre alphabetique des auteurs.
class SortByAuthor : public ISortStrategy
{
public:
    bool Before(const Book& book, const Book& other, std::string& output) const override;
    std::string GetName() const override
    {
        return "auteur";
    }
};
