#pragma once

#include "Interfaces/ISortStrategy.h"

// Ordre alphabétique des titres.
class SortByTitle : public ISortStrategy
{
public:
    bool Before(const Book& book, const Book& other, std::string& output) const override;
    std::string GetName() const override
    {
        return "titre";
    }
};
