#pragma once

#include <fstream>
#include <string>

// Singleton : un seul journal partage par tout le programme.
class LibraryLogger
{
private:
    // Fichier dans lequel les evenements sont enregistrés.
    std::ofstream file_;

    // Numero de la prochaine ligne du journal.
    int nextNumber_ = 1;

    // Constructeur prive : impossible de creer un logger directement.
    LibraryLogger();

public:
    // Une seule instance est accessible dans tout le programme.
    static LibraryLogger& GetInstance();

    // Enregistre un évènement avec son numéro.
    void Log(const std::string& message);

    // Copie interdite pour garantir une seule instance.
    LibraryLogger(const LibraryLogger&) = delete;
    LibraryLogger& operator=(const LibraryLogger&) = delete;

    // Déplacement interdit également.
    LibraryLogger(LibraryLogger&&) = delete;
    LibraryLogger& operator=(LibraryLogger&&) = delete;
};
