#pragma once

#include "Factories/FactoryRegistry.h"

class Book;

// Registre specialise pour la création des livres.
//
// Il hérite du registre générique FactoryRegistry<Book>
// et enregistre automatiquement les trois fabriques
// concretes lors de sa construction.
class BookFactoryRegistry final : public FactoryRegistry<Book>
{
public:
    // Enregistre les fabriques des livres papier,
    // numeriques et audio.
    BookFactoryRegistry();
};
