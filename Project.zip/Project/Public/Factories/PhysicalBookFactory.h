#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Interfaces/IFactory.h"

class Book;

// Fabrique concrete pour les livres papier.
//
// Transforme les champs d'une ligne CSV en un PhysicalBook.
// La fabrique retourne un unique_ptr<Book> pour permettre
// le polymorphisme et le transfert de propriété.
class PhysicalBookFactory final : public IFactory<Book>
{
public:
    // Cree un livre papier apres validation des champs.
    //
    // Format attendu :
    // physical,titre,auteur,rayon,etat
    //
    // Retourne nullptr si les donnees sont invalides.
    std::unique_ptr<Book> Create(const std::vector<std::string>& fields) const override;
};
