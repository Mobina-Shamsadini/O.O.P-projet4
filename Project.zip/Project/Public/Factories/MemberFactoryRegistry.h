#pragma once

#include "Factories/FactoryRegistry.h"

class Member;

// Registre specialise pour la creation des membres.
//
// Il hérite du régistre generique FactoryRegistry<Member>
// et enregistre automatiquement les fabriques
// des etudiants et des enseignants.
class MemberFactoryRegistry final : public FactoryRegistry<Member>
{
public:
    // Initialise le registre avec les fabriques
    // correspondant aux types du fichier members.csv.
    MemberFactoryRegistry();
};
