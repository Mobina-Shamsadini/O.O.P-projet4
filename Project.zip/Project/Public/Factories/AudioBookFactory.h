#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Interfaces/IFactory.h"

class Book;

// Fabrique concrete pour les livres audio.
//
// Transforme les champs CSV en un objet AudioBook.
// Retourne un unique_ptr<Book> pour permettre
// le polymorphisme et le transfert de propriete.
class AudioBookFactory final : public IFactory<Book>
{
public:
    // Crée un livre audio apres validation.
    //
    // Format attendu :
    // audio,titre,auteur,narrateur,duree,licences
    //
    // Retourne nullptr si les donnees sont invalides.
    std::unique_ptr<Book> Create(const std::vector<std::string>& fields) const override;
};
