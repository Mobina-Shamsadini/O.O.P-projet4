#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Interfaces/IFactory.h"

class Member;

// Fabrique concrete pour les membres etudiants.
//
// Transforme les champs CSV en un objet Student.
// Retourne un unique_ptr<Member> pour permettre
// le polymorphisme et le transfert de propriete.
class StudentFactory final : public IFactory<Member>
{
public:
    // Format attendu :
    // student, nom, identifiant, programme, notifications
    //
    // Retourne nullptr si les donnees sont invalides.
    std::unique_ptr<Member> Create(const std::vector<std::string>& fields) const override;
};
