#pragma once

#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "Interfaces/IFactory.h"

// Registre generique de fabriques.
//
// T represente le type de base des objets créés
// (Book ou Member).
//
// Le registre est propriétaire de ses fabriques.
// Chaque fabrique est associee à une cle CSV.
// Template : tout le code est dans le .h, aucun .cpp.
template <typename T> class FactoryRegistry
{
private:
    // Association entre une cle et sa fabrique.
    //
    // Exemple :
    // "physical" --> PhysicalBookFactory
    // "ebook"    -> EBookFactory
    // "audio"    -> AudioBookFactory
    //
    // unique_ptr assure la destruction automatique
    // des fabriques lors de la destruction du registre.
    std::map<std::string, std::unique_ptr<IFactory<T>>> factories_;

protected:
    // Seuls les registres concrets choisissent leurs fabriques.
    // Le registre prend possession de la fabrique.
    void RegisterFactory(const std::string& key, std::unique_ptr<IFactory<T>> factory)
    {
        factories_[key] = std::move(factory);
    }

public:
    FactoryRegistry() = default;
    virtual ~FactoryRegistry() = default;

    // Le registre est l'unique proprietaire de ses fabriques.
    // La copie est interdite.
    FactoryRegistry(const FactoryRegistry&) = delete;
    FactoryRegistry& operator=(const FactoryRegistry&) = delete;

    // ==================== CREATION ====================

    // Cree un objet selon le premier champ CSV.
    // Aucun if/else sur le type : la table choisit la fabrique.
    //
    // Retourne nullptr lorsque la ligne est vide, que le type
    // est inconnu ou que la fabrique refuse les donnees.
    // CsvLoader journalise ensuite la ligne avec [IGNORE].
    std::unique_ptr<T> Create(const std::vector<std::string>& fields) const
    {
        if (fields.empty())
        {
            return nullptr;
        }

        const auto found = factories_.find(fields.front());

        if (found == factories_.end())
        {
            return nullptr;
        }

        return found->second->Create(fields);
    }
};
