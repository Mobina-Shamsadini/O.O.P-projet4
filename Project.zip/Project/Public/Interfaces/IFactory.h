#pragma once

#include <memory>
#include <string>
#include <vector>

// Interface generique du patron Factory Method.
//
// T represente le type de base des objets crées
// (par exemple Book ou Member).
//
// Chaque fabrique concrete doit implementer Create()
// pour construire un objet a partir des champs CSV.
// Template : tout le code est dans le .h, aucun .cpp.
template <typename T> class IFactory
{
public:
    // Destructeur virtuel pour permettre la destruction
    // correcte des fabriques derivees.
    virtual ~IFactory() = default;

    // Cree un objet a partir des champs d'une ligne CSV.
    //
    // Toute la ligne est validee AVANT la construction :
    // en cas de donnees invalides, la fabrique retourne nullptr.
    // Aucune exception n'est lancee.
    //
    // Le pointeur unique transfere la propriete de l'objet
    // au code appelant.
    virtual std::unique_ptr<T> Create(const std::vector<std::string>& fields) const = 0;
};
