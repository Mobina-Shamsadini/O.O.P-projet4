#pragma once

// Interface commune aux livres et aux membres.
// Permet un affichage polymorphe sans connaitre le type concret.
class IDisplayable
{
public:
    virtual ~IDisplayable() = default;

    virtual void Display() const = 0;
};
