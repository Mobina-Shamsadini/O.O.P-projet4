#pragma once

#include <string>

// Interface du patron State.
// Chaque etat decide si une operation est autorisée.
//
// Retourne un pointeur vers le prochain état si l'action est acceptée,
// ou nullptr si elle est refusée.
//
// Les états ne modifient jamais directement les livres.
class IBookState
{
public:
    // Destructeur virtuel de l'interface.
    virtual ~IBookState() = default;

    // Etat suivant apres un emprunt.
    virtual const IBookState* Checkout() const = 0;

    // Etat suivant apres un retour.
    virtual const IBookState* Return() const = 0;

    // Etat suivant apres une reservation.
    virtual const IBookState* Reserve() const = 0;

    // Nom exact de l'etat, utilise notamment dans le journal.
    virtual std::string GetLabel() const = 0;
};
