#pragma once

#include <string>

class Book;

// Strategy - un critère de tri. Le tri ne pose qu'une question :
// book doit-il passer avant other ?
class ISortStrategy
{
public:
    virtual ~ISortStrategy() = default;

    // Vrai si book doit etre place avant other ; output explique la reponse.
    virtual bool Before(const Book& book, const Book& other, std::string& output) const = 0;

    // Le nom du critere, ecrit dans la ligne [TRI] du journal.
    virtual std::string GetName() const = 0;
};
