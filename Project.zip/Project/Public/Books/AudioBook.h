#pragma once

#include <string>

#include "Books/Book.h"

// Livre audio : nombre limite d'écoutes simultanées.
//
// Le titre ne sort (CheckedOutState) qu'au depart de la dernière
// licence, et redevient disponible dès qu'une licence revient.
class AudioBook final : public Book
{
private:
    // Informations propres au livre audio.
    std::string narrator_;
    int durationMinutes_;
    int maxListeners_;

    // Nombre d'écoutes actuellement actives.
    int activeListeners_ = 0;

public:
    AudioBook(std::string title, std::string author, std::string narrator, int durationMinutes,
              int maxListeners);

    // Nom du type concret.
    std::string GetTypeLabel() const override;

    // ==================== EMPRUNT ET RETOUR ====================

    bool Checkout(std::string& output) override;
    bool Return(std::string& output) override;

    // ==================== AFFICHAGE ====================

    void Display() const override;
};
