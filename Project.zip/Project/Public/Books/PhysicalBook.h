#pragma once

#include <string>

#include "Books/Book.h"

// Livre papier : un seul exemplaire, range sur un rayon.
// Les regles d'emprunt et de retour sont celles de Book :
// le patron State refuse un livre deja emprunté ou endommagé.
class PhysicalBook final : public Book
{
private:
    // Emplacement du livre dans la bibliotheque.
    std::string shelf_;

public:
    // damaged indique si le livre est initialement endommagé.
    PhysicalBook(std::string title, std::string author, std::string shelf, bool damaged);

    // Nom du type concret.
    std::string GetTypeLabel() const override;

    // Affichage polymorphe.
    void Display() const override;
};
