#pragma once

#include <string>

#include "Interfaces/IDisplayable.h"

class IBookState;

// Classe de base abstraite de tous les livres.
//
// Le patron State gere les transitions entre les etats :
// l'état courant repond par l'état suivant ou refuse (nullptr),
// et le livre applique la reponse dans ApplyTransition(),
// seul endroit qui journalise [ETAT].
//
// Les classes derivées redéfinissent l'emprunt et le retour
// pour garder leurs propres regles (prets, licences).
class Book : public IDisplayable
{
private:
    std::string title_;
    std::string author_;

    // Etat courant : pointeur non propriétaire.
    // Les états sont des Singletons partages entre les livres.
    const IBookState* state_;

    // Compteur des livres actuellement vivants.
    static int liveCount_;

protected:
    // Constructeur réservé aux classes dérivées.
    Book(std::string title, std::string author, const IBookState& initialState);

    // Vrai si l'état accepte l'action (nextState non nul).
    // Sinon, output explique le refus avec l'etat courant.
    bool Allows(const IBookState* nextState, const std::string& refusal, std::string& output) const;

    // Applique une transition acceptee et la journalise.
    bool ApplyTransition(const IBookState* nextState, const std::string& refusal,
                         std::string& output);

public:
    // Destructeur virtuel : destruction correcte des enfants.
    ~Book() override;

    // Copie et deplacement interdits.
    Book(const Book&) = delete;
    Book& operator=(const Book&) = delete;
    Book(Book&&) = delete;
    Book& operator=(Book&&) = delete;

    // ==================== ACCESSEURS ====================

    const std::string& GetTitle() const;
    const std::string& GetAuthor() const;

    // Acces en lecture a l'etat courant.
    const IBookState& GetState() const;
    std::string GetStateLabel() const;

    // Nom du type concret : Papier, Numerique ou Audio.
    virtual std::string GetTypeLabel() const = 0;

    // Nombre de livres vivants.
    static int GetLiveCount();

    // ==================== OPERATIONS ====================

    // Tente un emprunt selon les règles du type de livre.
    virtual bool Checkout(std::string& output);

    // Tente un retour selon les règles du type de livre.
    virtual bool Return(std::string& output);

    // Tente de réserver le livre.
    bool Reserve(std::string& output);

    // Verifie la disponibilité et explique le résultat.
    bool IsAvailable(std::string& output) const;

    // Vrai si le livre est sorti : utilisé par Library
    // pour savoir si une liste d'attente à un sens.
    bool IsCheckedOut() const;

    // ==================== AFFICHAGE ====================

    // Chaque enfant possede son propre format d'affichage.
    void Display() const override = 0;
};
