#pragma once

#include <string>

#include "Books/Book.h"

// Livre numerique : nombre illimite d'emprunts simultanes.
//
// Le livre reste disponible meme lorsqu'il est emprunté.
// Le compteur activeLoans_ indique le nombre de prêts en cours.
class EBook final : public Book
{
private:
    // Adresse de telechargement du livre.
    std::string downloadUrl_;

    // Taille du fichier en megaoctets.
    int fileSizeMb_;

    // Nombre d'emprunts actuellement actifs.
    int activeLoans_ = 0;

public:
    EBook(std::string title, std::string author, std::string downloadUrl, int fileSizeMb);

    // Nom du type concret.
    std::string GetTypeLabel() const override;

    // ==================== EMPRUNT ET RETOUR ====================

    // Autorise plusieurs emprunts simultanes, sans transition.
    bool Checkout(std::string& output) override;

    // Diminue le compteur si un emprunt existe.
    bool Return(std::string& output) override;

    // ==================== AFFICHAGE ====================

    void Display() const override;
};
