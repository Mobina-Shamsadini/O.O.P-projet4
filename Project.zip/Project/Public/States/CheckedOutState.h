#pragma once

#include <string>

#include "Interfaces/IBookState.h"

// Etat d'un livre deja emprunté.
//
// Singleton : tous les livres dans cet état partagent
// la même instance de CheckedOutState.
class CheckedOutState final : public IBookState
{
private:
    // Constructeur privé : empeche la creation directe.
    CheckedOutState() = default;

public:
    // Retourne l'instance unique de cet etat.
    static const CheckedOutState& GetInstance();

    // Copie interdite pour garantir le Singleton.
    CheckedOutState(const CheckedOutState&) = delete;
    CheckedOutState& operator=(const CheckedOutState&) = delete;

    // Transitions possibles depuis CheckedOutState.
    const IBookState* Checkout() const override;
    const IBookState* Return() const override;
    const IBookState* Reserve() const override;

    // Nom exact de l'etat pour le journal.
    std::string GetLabel() const override;
};
