#pragma once

#include <string>

#include "Interfaces/IBookState.h"

// Etat d'un livre endommage.
//
// Singleton : tous les livres endommagés partagent
// la même instance de DamagedState.
class DamagedState final : public IBookState
{
private:
    // Constructeur privé : empêche la création directe.
    DamagedState() = default;

public:
    // Retourne l'instance unique de cet etat.
    static const DamagedState& GetInstance();

    // Copie interdite pour garantir le Singleton.
    DamagedState(const DamagedState&) = delete;
    DamagedState& operator=(const DamagedState&) = delete;

    // Transitions possibles depuis DamagedState.
    const IBookState* Checkout() const override;
    const IBookState* Return() const override;
    const IBookState* Reserve() const override;

    // Nom exact de l'état pour le journal.
    std::string GetLabel() const override;
};
