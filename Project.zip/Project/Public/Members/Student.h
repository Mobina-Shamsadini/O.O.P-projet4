#pragma once

#include "Members/Member.h"

// Membre etudiant : maximum de deux emprunts simultanés.
class Student : public Member
{
private:
    static constexpr int MAX_BOOKS = 2;

public:
    Student(const std::string& name, int memberId, const std::string& program,
            bool wantsNotifications);

    std::string GetTypeLabel() const override
    {
        return "Etudiant";
    }

    int GetMaxBooks() const override
    {
        return MAX_BOOKS;
    }
};
